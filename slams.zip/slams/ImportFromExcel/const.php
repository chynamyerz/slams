<?php
define("HOST", "127.0.0.1");
define("USR", "root");
define("PWD", "Mzukwase11");
define("DB", "project_v1");
?>