<?php
include("const.php");
$conn = mysqli_connect(HOST,USR,PWD,DB);

if(isset($_POST['submit'])){
	echo $filename = $_FILES['file']['tmp_name'];
	if($_FILES['file']['size'] > 0){
		$file = fopen($filename, "r");
		
		
		if ( ! isset($emapData[1])) {
		$emapData[1] = null;
		}
		while (($emapData = fgetcsv($file, 10000, ",")) != FALSE)
		{	
			$student_number = $emapData[1];
			$student_email = $emapData[1]."@stu.unizulu.ac.za";
			$student_qualification = $emapData[2];
			$student_name = $emapData[8];
			$student_surname = $emapData[7];

			$sql = "INSERT INTO student(student_number, name, surname, email, qualification) VALUES('$student_number', '$student_name', '$student_surname', '$student_email', '$student_qualification')";
			//$sql = "INSERT INTO student_course(student_number, course_code) VALUES('$emapData[1]', '$emapData[3]')";
			$res = $conn->query($sql);
		}
		fclose($file);
		echo 'successful upload';
	}
	else 
		echo 'invalid file upload';
}

?>
<!DOCTYPE html>
<html>
	<head>
		<title>Upload file</title>
	</head>
	<body>
		<form method='POST' enctype='multipart/form-data'>
			<div align="center">
				<p> Upload Excel file with CSV extension: <input type='file' name='file' /></p>
				<p><input type='submit' name='submit' value='import' /></p>
			</div>
		</form>
	</body>
</html>	
