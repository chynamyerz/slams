<?php
	session_start();
	//Maintaining the user session. if the user is not logged in then redirect to log in page.
	if(isset($_SESSION['username']) == ''){
?>
	<script>
		alert("You must login first");
		window.location.href = "../index.php";
	</script>
<?php
		
	}
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" />

	<script src="js/jquery-1.12.4.js"></script>
  	<script src="js/jquery-ui.js"></script>
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		//PrettyPhoto
		jQuery(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});
		
		//BlackAndWhite
		$(window).load(function(){
			$('.client_img').BlackAndWhite({
				hoverEffect : true, // default true
				// set the path to BnWWorker.js for a superfast implementation
				webworkerPath : false,
				// for the images with a fluid width and height 
				responsive:true,
				// to invert the hover effect
				invertHoverEffect: false,
				// this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
				intensity:1,
				speed: { //this property could also be just speed: value for both fadeIn and fadeOut
					fadeIn: 300, // 200ms for fadeIn animations
					fadeOut: 300 // 800ms for fadeOut animations
				},
				onImageReady:function(img) {
					// this callback gets executed anytime an image is converted
				}
			});
		});
		
	</script>
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
	<!-- HEADER -->
	<header>
		
		<!-- MENU BLOCK -->
		<div class="menu_block">
		
			<!-- CONTAINER -->
			<div class="container clearfix">
				
				<!-- LOGO -->
				<div class="logo pull-left">
					<a href="../index.php" ><img src="images/logo.jpg" ></a>
				</div><!-- //LOGO -->
				
				<!-- MENU -->
				<div class="pull-right">
					<nav class="navmenu center">
						<ul>
							<li class="first active scroll_btn"><a href="admin_home.php" >Home</a></li>
							<li class="scroll_btn last">
								<form>
									<button class="btn btn-primary" ng-click="logout()">
										Logout  <i class="fa fa-sign-out"></i>
									</button>
								</form>
							</li>
						</ul>
					</nav>
				</div><!-- //MENU -->
			</div><!-- //MENU BLOCK -->
		</div><!-- //CONTAINER -->
	</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	
		<!--Admin Sign-In -->
		<section id="about">
			<div class="container-fluid col-md-8 col-md-offset-2" id="student-form">
				<h2 style="text-align: center;">Choose Who To Administrator</h2>
				
			    <div class="form-group">
					<button ng-click="directPage('Students')" class="btn btn-success btn-block" >Students Administratoring</button>				    			  	
				</div>
				
			  	<div class="form-group">
				    
				    <button ng-click="directPage('Staffs')" class="btn btn-success btn-block" >Staffs Administratoring</button>
			  	</div>		
				
			</div><!-- end of the prototyping form -->
		</section>


	</div>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->
	
</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery-ui.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/FileSaver.js" type="text/javascript"></script>
<script src="js/Blob.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>