
	/*$( "#daydatepicker" ).datepicker({
			firstDay: 1,
			showButtonPanel: true,
			minDate: '2016-02-01',
			maxDate: '2016-11-30',
			dateFormat: 'yy-mm-dd'
	});

	$( "#weekdatepicker" ).datepicker({
		firstDay: 1,
		showButtonPanel: true,
		//minDate: '2016-02-01',
		maxDate: 'today',
		//dateFormat: 'yy-mm-dd',
		showWeek: true,
		onSelect: function(dateText, inst){
			dateFormat: $.datepicker.iso8601Week(new Date(dateText)),
						$(this).val($.datepicker.iso8601Week(new Date(dateText)));
		}
		
	});

	$( "#monthdatepicker" ).datepicker({
		changeMonth: true,
		firstDay: 1,
		dateFormat: 'mm'
	});*/


$(function(){
	$(document).on("hidden.bs.modal", "dayAttendanceModal", function(){
		$(this).find("form").removeData();
	});
});


