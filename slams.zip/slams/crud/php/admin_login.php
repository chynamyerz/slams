<?php
    session_start();
    //database settings
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

	if(!empty($data->admin) and !empty($data->password)){
        $username = $data->admin;
        $password = $data->password;

	    $query = "SELECT * FROM admin WHERE admin=:username AND password=:password";

        $query_params = array(':username'=>$username, ':password'=>$password);

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 

        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $_SESSION['admin'] = $row['admin'];
            echo $_SESSION['admin'];
        }else{
            echo "Wrong Credentials";
        }
    }else{
        if(empty($data->admin)){
            echo "Username Empty";
        }else if(empty($data->password)){
            echo "Password Empty";
        }
    }
?>