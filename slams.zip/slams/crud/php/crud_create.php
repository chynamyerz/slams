<?php
	require("dbconnect.php");
	//get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->action) and $data->action == "Students"){
        if(!empty($data->student_number) and !empty($data->fname) and !empty($data->lname)){
            $student_number = $data->student_number;
            $fname = $data->fname;
            $lname = $data->lname;

            $query = "SELECT * FROM student WHERE student_number=:student_number AND name=:fname AND surname=:lname";

            $query_params = array(':student_number'=>$student_number, ':fname'=>$fname, ':lname'=>$lname);

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                echo "Already Exist";
            }else{
                $query = 'INSERT INTO student (student_number, name, surname) VALUES(:student_number, :fname, :lname)';

                $query_params = array(':student_number'=>$student_number, ':fname'=>$fname, ':lname'=>$lname); 

                try { 
                    // Execute the query 
                    $stmt = $db->prepare($query); 
                    $result = $stmt->execute($query_params); 
                }catch(PDOException $ex) { 
                    // Note: On a production website, you should not output $ex->getMessage(). 
                    // It may provide an attacker with helpful information about your code.  
                    die("Failed to run query: Please provide valid information"); 
                } 

                if($result){
                    echo "Success";
                }else{
                    echo "No Success";
                }
            }
        }else{
            if(empty($data->student_number)){
                echo "Student Number Empty";
            }else if(empty($data->fname)){
                echo "Student Name Empty";
            }else if(empty($data->lname)){
                echo "Student Surname Empty";
            }
        }
    }else if(!empty($data->action) and $data->action == "Staffs"){
        if(!empty($data->staff_number) and !empty($data->fname) and !empty($data->lname)){
            $staff_id = $data->staff_number;
            $fname = $data->fname;
            $lname = $data->lname;

            $query = "SELECT * FROM lecture WHERE staff_id=:staff_id AND name=:fname AND surname=:lname";

            $query_params = array(':staff_id'=>$staff_id, ':fname'=>$fname, ':lname'=>$lname);

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                echo "Already Exist";
            }else{
                $query = 'INSERT INTO lecture (staff_id, name, surname, password) VALUES(:staff_id, :fname, :lname, :password)';

                $query_params = array(':staff_id'=>$staff_id, ':fname'=>$fname, ':lname'=>$lname, ':password'=>"password"); 

                try { 
                    // Execute the query 
                    $stmt = $db->prepare($query); 
                    $result = $stmt->execute($query_params); 
                }catch(PDOException $ex) { 
                    // Note: On a production website, you should not output $ex->getMessage(). 
                    // It may provide an attacker with helpful information about your code.  
                    die("Failed to run query: Please provide valid information"); 
                } 

                if($result){
                    echo "Success";
                }else{
                    echo "No Success";
                }
            }
        }else{
            if(empty($data->staff_number)){
                echo "Staff Number Empty";
            }else if(empty($data->fname)){
                echo "Staff Name Empty";
            }else if(empty($data->lname)){
                echo "Staff Surname Empty";
            }
        }
    }

    
?>