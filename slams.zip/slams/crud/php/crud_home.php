<?php
	//database settings
    require("dbconnect.php");
    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    $output = array();

    if(!empty($data->action) and $data->action == "Students"){

	    $sql = 'SELECT * FROM student ORDER BY student_number DESC';
		foreach ($db->query($sql) as $row) {
			$output[] = $row;
		}
		print json_encode($output);
	}

	else if(!empty($data->action) and $data->action == "Staffs"){
		$sql = 'SELECT * FROM lecture ORDER BY staff_id DESC';
		foreach ($db->query($sql) as $row) {
			$output[] = $row;
		}
		print json_encode($output);
	}
?>