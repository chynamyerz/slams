<?php

	require('dbconnect.php');

	//get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));
    if(!empty($data->action) and $data->action == "Students"){
        if(!empty($data->fname) and !empty($data->lname)){
            $student_number = test_input($data->student_number);
            $fname = test_input($data->fname);
            $lname = test_input($data->lname);

            $query = "UPDATE student SET name=:name, surname=:surname WHERE student_number=:student_number ";

            $query_params = array(':student_number'=>$student_number, ':name'=>$fname, ':surname' =>$lname);
            
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params);

            if($result){
                echo "Success";
            }else{
                echo "No Success";
            }
        }else{
            if(empty($data->fname)){
                echo "Student Name Empty";
            }else if(empty($data->lname)){
                echo "Student Surname Empty";
            }
        }
    }
    else if(!empty($data->action) and $data->action == "Staffs") {
        if(!empty($data->staff_number) and !empty($data->fname) and !empty($data->lname) and !empty($data->email) and !empty($data->department) and !empty($data->faculty) ){
            $staff_id = test_input($data->staff_number);
            $fname = test_input($data->fname);
            $lname = test_input($data->lname);
            $email = test_input($data->email);
            $department = test_input($data->department);
            $faculty = test_input($data->faculty);
            //$password = test_input($data->password);
            //$passwordMd5 = md5($password);

            $query = "UPDATE lecture SET name=:name, surname=:surname, email=:email, department=:department, faculty=:faculty WHERE staff_id=:staff_number ";

            $query_params = array(':staff_number'=>$staff_id, 'name'=>$fname, ':surname' =>$lname, ':email'=>$email, ':department'=>$department, ':faculty'=>$faculty);
            
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params);

            if($result){
                echo "Success";
            }else{
                echo "No Success";
            }
        }else{
            if(empty($data->fname)){
                echo "Staff Name Empty";
            }else if(empty($data->lname)){
                echo "Staff Surname Empty";
            }
        }
    }
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
	
?>