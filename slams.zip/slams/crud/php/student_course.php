<?php
	require('dbconnect.php');

	//get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));
    $output = array();
	if(!empty($data->action) and $data->action == "Students"){
		if(!empty($data->id)){
			$student_number = $data->id;

			$query = "SELECT * FROM student_course WHERE student_number=:student_number";

	        $query_params = array(':student_number'=>$student_number);

	        $stmt = $db->prepare($query); 
	        $result = $stmt->execute($query_params);    	
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				array_push($output, $row);
			}
			print json_encode($output);
		}
	}
	else if(!empty($data->action) and $data->action == "Staffs"){
		if(!empty($data->id)){
			$staff_number = $data->id;

			$query = "SELECT * FROM course WHERE staff_id=:staff_number";

	        $query_params = array(':staff_number'=>$staff_number);

	        $stmt = $db->prepare($query); 
	        $result = $stmt->execute($query_params);    	
			while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
		        array_push($output, $row);
		    }
		    print json_encode($output);
		}
	}
?>















