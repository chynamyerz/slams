<?php
	session_start();
	//Maintaining the user session. if the user is not logged in then redirect to log in page.
	if(isset($_SESSION['username']) == ''){
?>
	<script>
		alert("You must login first");
		window.location.href = "../index.php";
	</script>
<?php
		
	}
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" />

	<script src="js/jquery-1.12.4.js"></script>
  	<script src="js/jquery-ui.js"></script>
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		//PrettyPhoto
		jQuery(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});
		
		//BlackAndWhite
		$(window).load(function(){
			$('.client_img').BlackAndWhite({
				hoverEffect : true, // default true
				// set the path to BnWWorker.js for a superfast implementation
				webworkerPath : false,
				// for the images with a fluid width and height 
				responsive:true,
				// to invert the hover effect
				invertHoverEffect: false,
				// this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
				intensity:1,
				speed: { //this property could also be just speed: value for both fadeIn and fadeOut
					fadeIn: 300, // 200ms for fadeIn animations
					fadeOut: 300 // 800ms for fadeOut animations
				},
				onImageReady:function(img) {
					// this callback gets executed anytime an image is converted
				}
			});
		});
		
	</script>
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
	<!-- HEADER -->
	<header>
		
		<!-- MENU BLOCK -->
		<div class="menu_block">
		
			<!-- CONTAINER -->
			<div class="container clearfix">
				
				<!-- LOGO -->
				<div class="logo pull-left">
					<a href="../index.html" ><img src="images/logo.jpg" ></a>
				</div><!-- //LOGO -->
				
				<!-- MENU -->
				<div class="pull-right">
					<nav class="navmenu center">
						<ul>
							<li class="first active scroll_btn"><a href="admin_home.php" >Home</a></li>
							<li class="scroll_btn"><a href="staff_admin.php" >Staff</a></li>
							<li class="scroll_btn last">
								<form>
									<button class="btn btn-primary" ng-click="logout()">
										Logout  <i class="fa fa-sign-out"></i>
									</button>
								</form>
							</li>
						</ul>
					</nav>
				</div><!-- //MENU -->
			</div><!-- //MENU BLOCK -->
		</div><!-- //CONTAINER -->

		<!-- Create Modal -->
		<div class="modal fade" id="createModal" role="dialog">
		    <div class="modal-dialog modal-sm">
		    
		      	<!-- Modal content-->
		      	<div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title">Choose format</h4>
			        </div>
			        <div class="modal-body">
						<div class="container">
							<div class="container-fluid col-md-10 col-md-offset-1" id="student-form">
								<div class="row">
					    			<h2 style="text-align: center; margin-top: 1em;">Add Student Record</h2>
					    		</div>
						
								<form>
								    <div class="form-controls">
								    	<label class="control-label">Student Number</label>
								      	<input ng-model="student_number" type="text"  placeholder="Student Number" style="color:black;">
								    </div>
								  
								    <div class="form-controls">
								    	<label class="control-label">First Name</label>

								      	<input ng-model="fname" type="text" placeholder="Student Name" style="color:black;">
								    </div>
								  
								    <div class="form-controls">
								    	<label class="control-label">Last Name</label>
								      	<input ng-model="lname" type="text"  placeholder="Student Surname" style="color:black;">
								    </div>
								  
								  	<div>
									    <input ng-click="crudCreate('Students')" class="btn btn-success" value="Create">
									</div>
								</form>
							</div>		
					    </div> <!-- /container -->
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      </div>
		      
		    </div>
		</div><!-- //Create Modal -->

		<!-- Read Modal -->
		<div class="modal fade" id="readModal" role="dialog">
		    <div class="modal-dialog modal-sm">
		    
		      	<!-- Modal content-->
		      	<div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title">Choose format</h4>
			        </div>
			        <div class="modal-body">
			            <div class="container">
			            	<div class="row">
					    		<h3 style="text-align: center;padding-top: 0.5em;">Student Record</h3>
					    	</div>
							<div class="container-fluid col-md-8 col-md-offset-2" id="student-form">

							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 16px; ">Student Number:</span> 
							    	</label>
							    	<p style="font-size: 16px;">{{recordInfo.student_number}}</p>
							      	
							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 16px; ">Name:</span> 
							    	</label>
							    	<p style="font-size: 16px;">{{recordInfo.name}}</p>

							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 16px; ">Surname:</span> 
							    	</label>
							    	<p style="font-size: 16px;">{{recordInfo.surname}}</p>

							    </div>
							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 16px; ">Email-Address:</span> 
							    	</label>
							    	<p style="font-size: 16px;">{{recordInfo.email}}</p>

							    </div>
							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 16px; ">Qualification Code:</span> 
							    	</label>
							    	<p style="font-size: 16px;">{{recordInfo.qualification}}</p>

							    </div>
							    <div class="form-controls" >
							    	<label class="control-label" >
							    		<span style="font-size: 16px; ">Courses Registered:</span>	
							    	</label>
							    	<ol>
						    			<li ng-repeat="course in student_course" style="font-size: 16px;">{{course.course_code}}</li>
						    		</ol>
							    </div>
							</div>		
					    </div> <!-- /container -->
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      </div>
		      
		    </div>
		</div><!-- //Read Modal -->

		<!-- Update Modal -->
		<div class="modal fade" id="updateModal" role="dialog">
		    <div class="modal-dialog modal-sm">
		    
		      	<!-- Modal content-->
		      	<div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title">Choose format</h4>
			        </div>
			        <div class="modal-body">
			            <div class="container">
							<div class="container-fluid col-md-10 col-md-offset-1" id="student-form">
								<div class="row">
					    			<h3 style="text-align: center;">Update Student Record</h3>
					    		</div>

							    <div class="form-controls">
							    	<label class="control-label">Student Number</label>
							      	<input ng-model="updateInfo.student_number" type="text" style="color:black;" readonly="">
							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">First Name</label>

							      	<input ng-model="updateInfo.name" required pattern = "([A-Za-z]{1,50})" type="text" style="color:black;">
							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">Last Name</label>

							      	<input ng-model="updateInfo.surname" required pattern = "([A-Za-z]{1,50})" type="text" style="color:black;">
							    </div>
							  
							  	<div>
								    <button ng-click="updateRecord('Students')" class="btn btn-success">Submit</button>
								</div>
							</div>		
					    </div> <!-- /container -->
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      </div>
		      
		    </div>
		</div><!-- //Update Modal -->

	</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	

		<!--Admin controll -->
		<section>
			<div class="container">
		    	<div class="row">
		    		<h3 style="margin-top: 1em;">STUDENT CRUD</h3>
		    		</div>
					<div class="row">
						<!--<p>
							<button class="btn btn-success" data-toggle="modal" data-target="#createModal">Create</button>
						</p>-->
						
						<table class="table table-striped table-bordered">
				            <thead>
				                <tr>
				                  <th><input type="text" style="padding: 0px; margin: 0px; color: black; font-size: 14px;" placeholder="Student Number" ng-model="search" class="form-controls"></th>
				                  <th style="font-size: 14px;"><strong>First Name</strong></th>
				                  <th style="font-size: 14px;"><strong>Last Name</strong></th>
				                  <th style="font-size: 14px;"><strong>Action</strong></th>
				                </tr>
				            </thead>
				            <tbody>

					            <tr dir-paginate="student in allStudents | filter:search | itemsPerPage:10 ">
					            	<td>{{student.student_number}}</td>
					            	<td>{{student.name}}</td>
					            	<td>{{student.surname}}</td>
					            	<td width='250'>
					            		<button class="btn btn-primary" ng-click="readRecord('Students', student.student_number)" data-toggle="modal" data-target="#readModal">Read</button>
					            		<button class="btn btn-success" ng-click="updateModal('Students', student.student_number)" data-toggle="modal" data-target="#updateModal">Update</button>
					            		<button class="btn btn-danger" ng-click="deleteRecord('Students', student.student_number)">Delete</button>
					            	</td>
					            </tr>
						    </tbody>
			            </table>
			            <tfoot>
			            	<div style="font-size: 15px;" class="text-center">
			            		<dir-pagination-controls max-size="5" direction-links="true" boundary-links="true" ></dir-pagination-controls>
			            	</div>
			            	<br><br>
			            </tfoot>
		    		</div>
		    	</div>
		    </div> <!-- /container -->
		</section>

		<!-- CONTACTS -->
		<section id="contacts">
		</section><!-- //CONTACTS -->
	</div>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			</div><!-- //ROW -->
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->
	
</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery-ui.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/FileSaver.js" type="text/javascript"></script>
<script src="js/Blob.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>