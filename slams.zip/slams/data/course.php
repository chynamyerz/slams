<?php
	//Initiating the session for requesting particular courses with regards to lecturer unique identity.
	session_start();
	//Requiring database connection script for establishing interaction with the database.
	require("dbconnect.php");

	//Checks if the session is not empty
	if (!empty($_SESSION['username'])) {
		//Retrieve data from the database of courses to be displayed for selection 
		$query = "SELECT * FROM course WHERE staff_id=:staff_id";
		$query_params = array(':staff_id'=>$_SESSION['username']);
	    $stmt = $db->prepare($query); 
	    $result = $stmt->execute($query_params); 

	    if($row = $stmt->fetchAll(PDO::FETCH_ASSOC)){
	    	//feediing the output to the scope of angularjs.
	        print json_encode($row);
	    }
	}
	
?>