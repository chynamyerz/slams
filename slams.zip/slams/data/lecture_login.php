<?php
    //Initiating the session for identifying particular lecture identity.
    session_start();
    //Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");

    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));

    //Checks if the data input is not empty
    if(!empty($data->username) and !empty($data->password)){
        $username = test_input($data->username);
        $password = test_input($data->password);
        //Encrypting the password for security purpose.
        $passwordMd5 = md5($password);

	    $query = "SELECT * FROM lecture WHERE staff_id=:username AND password=:password";

        $query_params = array(':username'=>$username, ':password'=>$passwordMd5);

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
        //Checks the role of the loggin credentials and give right to privilleges where it due..
        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            if($row['staff_id'] === "admin"){
                $_SESSION['username'] = $row['staff_id'];
                echo $_SESSION['username'];
            }else if($row['staff_id'] === "admin1"){
                $_SESSION['username'] = $row['staff_id'];
                echo $_SESSION['username'];
            }else if($row['staff_id'] === "admin2"){
                $_SESSION['username'] = $row['staff_id'];
                echo $_SESSION['username'];
            }else{
                $_SESSION['username'] = $row['staff_id'];
                echo $_SESSION['username'];
            }
        }
    }else{
        echo "Empty";
    }
    //This test_input function ensures data entered is not malicious to the system
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>