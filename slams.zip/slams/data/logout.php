<?php 
	//Initiating the session for identifying particular lecture identity to be logged ot.
	session_start();
	//Clear the current user logged in credintials.
	unset($_SESSION['username']);
	//Checks if the seesion is cleared successfully.
	if(isset($_SESSION['username']) == ""){
		echo "Logged out";
	}
?>