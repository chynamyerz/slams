<?php
    //Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");

    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));

    //Declaring array variable to results the output.
    $output = array();

    //Checks if the data input is not empty.
    if(!empty($data->username)){
        $username = test_input($data->username);
        //Retrieving data from the database for the password recorvery purpose.
        $query = "SELECT * FROM lecture WHERE staff_id=:username";
        $query_params = array(':username'=>$username);
        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 

        //Checks if there is data returned from the request made to the database
        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $email = $row['email'];
            $subject = "Password Recorvery";
            //Creates the new random passwordfor the user 
            $password = randomPassword();
            //Encrypting the password for security purpose
            $passwordMd5 = md5($password);

            $message = "Hi ".$row['name']." \n\nWe see that you have forgotten you password and made a request for recorvery. \n\nYour New Password is: ".$password."\nYou can change it at any time!\n\nRegards \n\nSLAMS @ Unizulu.";

            $query = "UPDATE lecture SET password=:password WHERE staff_id=:staff_number";
            $query_params = array(':password'=>$passwordMd5, ':staff_number'=>$username);   
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params);
            
            //If network connection is established this will send an email to the user email address 
            //$send_mail = mail($email,$subject,$message, "From: slams_unizulu@slams-unizulu.co.za");
            //If recorvering the password was the success or not, then, feed the result to angularjs for an appropriate message display.
            if($result){
                $jsonArrayItem['error_msg'] = "Success";
                $jsonArrayItem['error_pss'] = $password;
                array_push($output,$jsonArrayItem);
            }else{
                $jsonArrayItem['error_msg'] = "No Success";
                array_push($output,$jsonArrayItem);
            }
        }
        print json_encode($output);
    }else{
        echo "Empty";
    }
    //This test_input function ensures data entered is not malicious to the system
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    //This is the function that generate random passwords from time to time
    function randomPassword(){
        $string = md5(time());
        $string = substr($string, 0 , 4);
        return $string;
    }
?>