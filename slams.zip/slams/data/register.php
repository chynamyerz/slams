<?php
    //Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");

    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));

    //Checks if the data input is not empty
    if(!empty($data->qauntity) and !empty($data->week_number)){
        $course_code = test_input($data->course_code);
        $week_number = test_input($data->week_number);

        $date = $week_number;
        $check = new DateTime($date);
        //Get the week number
        $week_number = $check->format("W");
        //Get the month number
        $month_number = $check->format("m");

        $lec_or_prac= test_input($data->lec_or_prac);
        $qauntity = test_input($data->qauntity);

        //Checks which semester we are currently in and whether dealing with the lecture/ practical periods
        if($lec_or_prac === "Lectures"){
            if($date >= "2016-06-30"){
                $semester = "s2";
            }else if($date < "2016-06-30"){
                $semester = "s1";
            }
            //Insert in to the database for the register settings.
            $query = 'INSERT INTO register_format (course_code, month, week, qauntity, lec_or_prac, semester) 
                    VALUES(:course_code, :month_number, :week_number, :qauntity, :lec_or_prac, :semester)';
            $query_params = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':week_number'=>$week_number, ':qauntity'=>$qauntity, ':lec_or_prac'=>"L", ':semester'=>$semester); 

            try { 
                // Execute the query 
                $stmt = $db->prepare($query); 
                $result = $stmt->execute($query_params); 
            }catch(PDOException $ex) { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: Please provide valid information"); 
            } 
            //If setting the register headings was a success or not.
            if($result){
                echo "L Captured";
            }else{
                echo "L Not Captured";
            }

        }else if($lec_or_prac === "Practicals"){
            if($date >= "2016-06-30"){
                $semester = "s2";
                
            }else if($date < "2016-06-30"){
                $semester = "s1";
            }
            //Insert into the database for the register settings.
            $query = 'INSERT INTO register_format (course_code, month, week, qauntity, lec_or_prac, semester) 
                    VALUES(:course_code, :month_number, :week_number, :qauntity, :lec_or_prac, :semester)';
            $query_params = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':week_number'=>$week_number, ':qauntity'=>$qauntity, ':lec_or_prac'=>"P", ':semester'=>$semester); 
            
            try { 
                // Execute the query 
                $stmt = $db->prepare($query); 
                $result = $stmt->execute($query_params); 
            }catch(PDOException $ex) { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: Please provide valid information"); 
            } 
            //If setting the register headings was a success or not.
            if($result){
                echo "P Captured";
            }else{
                echo "P Not Captured";
            }
        }
    }else{
        echo "Empty";
    }
    //This test_input function ensures data entered is not malicious to the system
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>