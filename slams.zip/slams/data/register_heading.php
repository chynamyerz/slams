<?php
    //Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");

    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));
    //Declaring array variable to results the output.
    $output = array();

    //Checks if data input is not empty for the day format
    if(!empty($data->course_code) and !empty($data->attendance_date) and !empty($data->lec_or_prac)){
        $output[] = array('qauntity' => 1 );

        print json_encode($output);
    }
    //Checks if data input is not empty for the week format
    else if(!empty($data->course_code) and !empty($data->week_number) and !empty($data->lec_or_prac)){
        $course_code = test_input($data->course_code);
        $week_number = test_input($data->week_number);
        $date = $week_number;
        $check = new DateTime($date);
        //Get week number of the date entered
        $week_number = $check->format("W");
        $lec_or_prac = test_input($data->lec_or_prac);
        
        //Checks whether this deals with the lecture/ practical periods.
        if($lec_or_prac === "Lectures"){
            //Selecting desired data from the database
            $query = "SELECT * FROM register_format WHERE course_code=:course_code AND week =:week_number AND lec_or_prac=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT * FROM register_format WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");
        }

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
        //Collecting all the desired results from the database and feed to the angularjs
        while($row = $stmt->fetchAll(PDO::FETCH_ASSOC)){
            $output = $row;
        }
	
        print json_encode($output);
    }

    //Checks if data input is not empty for the month format
    else if(!empty($data->course_code) and !empty($data->month_number) and !empty($data->lec_or_prac)){
        $course_code = test_input($data->course_code);
        $month_number = test_input($data->month_number);

        $date = $month_number;
        $check = new DateTime($date);
        //Get month number of the date entered
        $month_number = $check->format("m");
        $lec_or_prac = test_input($data->lec_or_prac);
        //Controlling the appearance of the month number
        $count = 0;
        //Checks whether this deals with the lecture/ practical periods.
        if($lec_or_prac === "Lectures"){
            //Selecting desired data from the database
            $query = "SELECT * FROM register_format WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"L");
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT * FROM register_format WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"P");
        }

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
        //Collecting all the desired results from the database and feed to the angularjs
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $count += $row['qauntity'];
        }
        $output[] = array("qauntity"=>$count);
    
        print json_encode($output);
    }

    //Checks if data input is not empty for the semester format
    else if(!empty($data->course_code) and !empty($data->lec_or_prac) and !empty($data->semester)){
        $course_code = test_input($data->course_code);
        $lec_or_prac = test_input($data->lec_or_prac);
        $attended_semester = test_input($data->semester);
        $count = 0;
        //Checks whether this deals with the lecture/ practical periods.
        if($lec_or_prac === "Lectures"){
            //Selecting desired data from the database
            $query = "SELECT * FROM register_format WHERE course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':semester'=>$attended_semester,':lec_or_prac'=>"L");
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT * FROM register_format WHERE course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':semester'=>$attended_semester, ':lec_or_prac'=>"P");
        }

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
        //Collecting all the desired results from the database and feed to the angularjs
        while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $count += $row['qauntity'];
        }
    
        $output[] = array("qauntity"=>$count);
    
        print json_encode($output);
    }
    //This test_input function ensures data entered is not malicious to the system
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>