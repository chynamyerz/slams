<?php
	//Initiating the session for identifying particular lecture identity.
	session_start();
	//Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");

    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));
    //Checks if the input is not empty
    if (!empty($data->student_number)) {
    	$student_number = test_input($data->student_number);
    	//Getting currenttime
    	$current_time = date("h:i:s"); 
    	//Getting current date
    	$current_date = date("Y-m-d");
    	//Getting current day
    	$current_day = date("l");
    	$lecture_id = $_SESSION['lecturer'];
    	//Checks if the lecturer session is empty or not then responds accordingly
    	if(empty($_SESSION['lecturer'])){
    		echo "Wait";
    	}else{
    		$course_code = "";
	    	$lec_or_prac = "";
	    	//Select the currently set lucture venue by the lecturer
	    	$query = "SELECT lecture_venue FROM lecture WHERE staff_id=:lecture_id";
	        $query_params = array(':lecture_id'=>$lecture_id);
	        $stmt = $db->prepare($query); 
	        $result = $stmt->execute($query_params);
	        //Checks if there is data returened 
	        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
	        	//Checks if the venue field is empty or not
	        	if($row['lecture_venue'] != ""){
	        		$venue = $row['lecture_venue'];
	        		//Selects the course being conducted at that particular time.
	        		$query = "SELECT course_code, lecture_or_practical FROM course_venue WHERE room_number=:venue AND time_in<=:time_in AND time_out>=:time_out AND day=:day ";
			        $query_params = array(':venue'=>$venue, ':time_in'=>$current_time, ':time_out'=>$current_time, ':day'=>$current_day);
			        $stmt = $db->prepare($query); 
			        $result = $stmt->execute($query_params); 
			        //Checks if data being returned 
			        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
						$course_code = $row['course_code'];
			    		$lec_or_prac = $row['lecture_or_practical'];
			    		//Select the course accordingly
			    		$query = "SELECT * FROM student_course WHERE student_number=:student_number AND course_code=:course_code ";
				        $query_params = array(':student_number'=>$student_number, ':course_code'=>$course_code);
				        $stmt = $db->prepare($query); 
				        $result = $stmt->execute($query_params);    	
				        //Checks if data is being returned
				        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				        	//Selects the desired data accordingly
				        	$query = "SELECT * FROM student_attendance WHERE student_number=:student_number AND course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";
					        $query_params = array(':student_number'=>$student_number, ':course_code'=>$course_code, ':attendance_date'=>$current_date, ':lec_or_prac'=>$lec_or_prac);
					        $stmt = $db->prepare($query); 
					        $result = $stmt->execute($query_params);
					        //Checks if datais returned and feed the appropriate message to angularjs
					        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					        	echo "Already Exist";
					        }else{
					        	//Insert data to database for capturing attendance
					        	$query = 'INSERT INTO student_attendance (student_number, course_code, attendance_date, time_in, lecture_or_practical) 
			                        VALUES(:student_number, :course_code, :attendance_date, :time_in, :lec_or_prac)';
				                $query_params = array(':student_number'=>$student_number, ':course_code'=>$course_code, ':attendance_date'=>$current_date, ':time_in'=>$current_time, ':lec_or_prac'=>"L"); 

				                try { 
				                    // Execute the query 
				                    $stmt = $db->prepare($query); 
				                    $result = $stmt->execute($query_params); 
				                }catch(PDOException $ex) { 
				                    // Note: On a production website, you should not output $ex->getMessage(). 
				                    // It may provide an attacker with helpful information about your code.  
				                    die("Failed to run query: Please provide valid information"); 
				                } 
				                //If captured successfully then marked as attended else data won't be captured
				                if($result){
				                    echo "Captured";
				                }else{
				                    echo "Not Captured";
				                }
					        }
				        }else{
				        	echo "Not registerd";
				        }
			        }else{
			        	echo "No lecture";
			        }
			    }else{
		        	echo "Wait";
		        }
	        }
	    }
    }else{
    	echo "Empty";
    }
    //This test_input function ensures data entered is not malicious to the system
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

?>