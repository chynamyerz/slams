<?php
	//Requiring database connection script for establishing interaction with the database.
	require("dbconnect.php");
	//Declaring an array variable to hold the resulted output
	$data = array();

    //Retrieve data from the venue database to be displayed for selection 
	//A SELECT query is used to retrieve data from the database. 
	$query = "SELECT * FROM venue";
	//Collecting all the desired results from the database and feed to the angularjs
	foreach ($db->query($query) as $row) {
		$data[] = $row;
	}
	print json_encode($data);
?>