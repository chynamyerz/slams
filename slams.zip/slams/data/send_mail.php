<?php
    //Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");

    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));

    //Checks if data input is not empty
    if(!empty($data->email) and !empty($data->text)){
        $subject = "SLAMS User Message";
        $email = test_input($data->email);
        $message = test_input($data->text);
        //Checks if the email is sent succeesfully and respond accordingly.
        if(mail("slams_unizulu@slams-unizulu.co.za",$subject,$message, "From: ".$email)){
            echo "Success";
        }else{
            echo "No Success";
        }
    }
    //This test_input function ensures data entered is not malicious to the system
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>