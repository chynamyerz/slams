<?php
    //Requiring database connection script for establishing interaction with the database.
    require("dbconnect.php");
    //Get the input data in jason format from the angularjs http post service
    $data = json_decode(file_get_contents("php://input"));
    //Declaring array variable to results the output.
    $output = array();

    //Checks if data input is not empty foro the day attendance view
    if(!empty($data->course_code) and !empty($data->attendance_date) and !empty($data->lec_or_prac)){
        $course_code = test_input($data->course_code);
        $attendance_date = test_input($data->attendance_date);
        $lec_or_prac = test_input($data->lec_or_prac);
        //Checks whether dealing with lecuter/practical periods
        if($lec_or_prac === "Lectures"){
            //Retrieve student number fromthe database accordingly
            $query = "SELECT student_number FROM student_attendance WHERE course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':attendance_date'=>$attendance_date, ':lec_or_prac'=>"L");
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            //If data retrieved successfully
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                //Retrieve student's infromation accordingly
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";
                $query_params4 = array(':student_number'=>$row['student_number']);
                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);
                //Put the information to the output variable for proper viewing of attendance
                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = 1;
                    array_push($output,$jsonArrayItem);
                }
            }
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT student_number FROM student_attendance WHERE course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':attendance_date'=>$attendance_date, ':lec_or_prac'=>"P");
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            //If data retrieved successfully
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                //Retrieve student number fromthe database accordingly
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";
                $query_params4 = array(':student_number'=>$row['student_number']);
                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);
                //Put the information to the output variable for proper viewing of attendance
                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = 1;
                    array_push($output,$jsonArrayItem);
                }
            }
        }
        //Checks if there is data item inthe output array varaible
        if(count($output) > 0){
            $track = false;
            //Retrieve data accordingly from the database
            $query = "SELECT * FROM student_course WHERE course_code=:course_code";
            $query_params = array(':course_code'=>$course_code);
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            //Checks whether the data from the database already exist in the output variable
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                foreach($output as $item){
                    if($item['student_number'] == $row['student_number']){
                        $track = true;
                    }
                }
                //If data does not already exist then append it to the output variable.
                if($track == false){
                    //Retrieve it from the the database.
                    $query4 = "SELECT * FROM student WHERE student_number=:student_number";
                    $query_params4 = array(':student_number'=>$row['student_number']);
                    $stmt4 = $db->prepare($query4); 
                    $result4 = $stmt4->execute($query_params4);
                    //Feed it accordingly
                    while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                        $jsonArrayItem['student_number'] = $row4['student_number'];
                        $jsonArrayItem['name'] = $row4['name'];
                        $jsonArrayItem['surname'] = $row4['surname'];
                        $jsonArrayItem['qauntity'] = 0;
                        array_push($output,$jsonArrayItem);
                    }
                }
                //Update the tracking of whether the data already exist or not.
                $track = false;
            }
        }
        print json_encode($output);
    }
    //Checks if data input is not empty foro the week attendance view
    else if(!empty($data->course_code) and !empty($data->week_number) and !empty($data->lec_or_prac)){
        $course_code = test_input($data->course_code);
        $week_number = test_input($data->week_number);
        $date = $week_number;
        $check = new DateTime($date);
        //Get the week number for the specified date.
        $week_number = $check->format("W");
        $lec_or_prac = test_input($data->lec_or_prac);
        //Checks whether dealing with the lecture/practical periods
        if($lec_or_prac === "Lectures"){
            //Retrieve data from the database accordingly
            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $temp_student = "";
            $count = 0;
            //If data retrieved successfully
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_week = $check->format("W");
                //Checks if the week number from the database is the same as that entered
                if($attended_week==$week_number){
                    //When the temporal student number is the same the student number from the database increament the count, 
                    //Else set the count to value 1.
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }
                    //Retieve data from the database accordingly
                    $query1 = "SELECT * FROM student_week_attendance WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");
                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 
                    //Checks whether the data already exist or not in the database.
                    //If it does insert the new record.
                    //If it doesn't update the record accordingly.
                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_week_attendance (student_number, course_code, week, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :week_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"L");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_week_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"L");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                //Update the temporaly student number variable
                $temp_student = $row['student_number'];
            }
            //Then from the database retrieve data to be displayed accordingly for attendance viewing
            $query3 = "SELECT * FROM student_week_attendance WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
            $query_params3 = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");
            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 
            //According to unique student number retrieve student details
            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";
                $query_params4 = array(':student_number'=>$row3['student_number']);
                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);
                //Append those details accordingly to the output variable.
                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];
                    array_push($output,$jsonArrayItem);
                }
            }
        }else if($lec_or_prac === "Practicals"){
            //Retrieve data from the database accordingly
            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";
            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $temp_student = "";
            $count = 0;
            //If data retrieved successfully
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_week = $check->format("W");
                //Checks if the week number from the database is the same as that entered    
                if($attended_week==$week_number){
                    //When the temporal student number is the same the student number from the database increament the count, 
                    //Else set the count to value 1.
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }
                    //Retieve data from the database accordingly
                    $query1 = "SELECT * FROM student_week_attendance WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");
                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 
                    //Checks whether the data already exist or not in the database.
                    //If it does insert the new record.
                    //If it doesn't update the record accordingly.
                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_week_attendance (student_number, course_code, week, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :week_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"P");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_week_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"P");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                //Update the temporaly student number variable
                $temp_student = $row['student_number'];
            }
            //Then from the database retrieve data to be displayed accordingly for attendance viewing
            $query3 = "SELECT * FROM student_week_attendance WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
            $query_params3 = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");
            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 
            //According to unique student number retrieve student details
            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";
                $query_params4 = array(':student_number'=>$row3['student_number']);
                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);
                //Append those details accordingly to the output variable.
                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }
        //Checks if there is data item in the output array varaible
        if(count($output) > 0){
            $track = false;
            $query = "SELECT * FROM student_course WHERE course_code=:course_code";
            $query_params = array(':course_code'=>$course_code);
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $students = array();
            //Checks whether the data from the database already exist in the output variable
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                foreach($output as $item){
                    if($item['student_number'] == $row['student_number']){
                        $track = true;
                    }
                }
                //If data does not already exist then append it to the output variable.
                if($track == false){
                    $query4 = "SELECT * FROM student WHERE student_number=:student_number";
                    $query_params4 = array(':student_number'=>$row['student_number']);
                    $stmt4 = $db->prepare($query4); 
                    $result4 = $stmt4->execute($query_params4);
                    //Retrieve data from the database accordingly
                    while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                        $jsonArrayItem['student_number'] = $row4['student_number'];
                        $jsonArrayItem['name'] = $row4['name'];
                        $jsonArrayItem['surname'] = $row4['surname'];
                        $jsonArrayItem['qauntity'] = 0;
                        array_push($output,$jsonArrayItem);
                    }
                }
                //Update the tracking of whether the data already exist or not.
                $track = false;
            }
        }
        print json_encode($output);
    }

    //Checks if data input is not empty foro the month attendance view
    else if(!empty($data->course_code) and !empty($data->month_number) and !empty($data->lec_or_prac)){
        $course_code = test_input($data->course_code);
        $month_number = test_input($data->month_number);
        $date = $month_number;
        $check = new DateTime($date);
        //Get month number of the specified date
        $month_number = $check->format("m");
        $lec_or_prac = test_input($data->lec_or_prac);
        //Checks whether dealing with the lecture / practical periods
        if($lec_or_prac === "Lectures"){
        
            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_month = $check->format("m");
                
                if($attended_month==$month_number){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_month_attendance WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"L");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_month_attendance (student_number, course_code, month, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :month_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"L");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_month_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"L");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_month_attendance WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"L");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_month = $check->format("m");
                
                if($attended_month==$month_number){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_month_attendance WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"P");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_month_attendance (student_number, course_code, month, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :month_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"P");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_month_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"P");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_month_attendance WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"P");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }
        if(count($output) > 0){
            $track = false;
            $query = "SELECT * FROM student_course WHERE course_code=:course_code";

            $query_params = array(':course_code'=>$course_code);

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $students = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                foreach($output as $item){
                    if($item['student_number'] == $row['student_number']){
                        $track = true;
                    }
                }

                if($track == false){
                    $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                    $query_params4 = array(':student_number'=>$row['student_number']);

                    $stmt4 = $db->prepare($query4); 
                    $result4 = $stmt4->execute($query_params4);

                    while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                        $jsonArrayItem['student_number'] = $row4['student_number'];
                        $jsonArrayItem['name'] = $row4['name'];
                        $jsonArrayItem['surname'] = $row4['surname'];
                        $jsonArrayItem['qauntity'] = 0;

                        array_push($output,$jsonArrayItem);
                    }
                }
                $track = false;
            }
        }
        print json_encode($output);
    }

    else if(!empty($data->course_code) and !empty($data->lec_or_prac) and !empty($data->semester)){
        $course_code = test_input($data->course_code);
        $lec_or_prac = test_input($data->lec_or_prac);
        $attended_semester = test_input($data->semester);

        if($lec_or_prac === "Lectures"){

            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $semester = $row['semester'];
                
                if($attended_semester==$semester){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_semester_attendance WHERE student_number=:student_number AND course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':semester'=>$semester, ':lec_or_prac'=>"L");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_semester_attendance (student_number, course_code, semester, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :semester, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':semester'=>$semester, ':count'=>$count, ':lec_or_prc'=>"L");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_semester_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':semester'=>$semester, ':count'=>$count, ':lec_or_prc'=>"L");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_semester_attendance WHERE course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':semester'=>$semester, ':lec_or_prac'=>"L");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }else if($lec_or_prac === "Practicals"){

            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $semester = $row['semester'];
                
                if($attended_semester==$semester){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_semester_attendance WHERE student_number=:student_number AND course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':semester'=>$semester, ':lec_or_prac'=>"P");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_semester_attendance (student_number, course_code, semester, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :semester, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':semester'=>$semester, ':count'=>$count, ':lec_or_prc'=>"P");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_semester_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':semester'=>$semester, ':count'=>$count, ':lec_or_prc'=>"P");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_semester_attendance WHERE course_code=:course_code AND semester=:semester AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':semester'=>$semester, ':lec_or_prac'=>"P");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }
        if(count($output)){
            $track = false;
            $query = "SELECT * FROM student_course WHERE course_code=:course_code";

            $query_params = array(':course_code'=>$course_code);

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $students = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                foreach($output as $item){
                    if($item['student_number'] == $row['student_number']){
                        $track = true;
                    }
                }

                if($track == false){
                    $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                    $query_params4 = array(':student_number'=>$row['student_number']);

                    $stmt4 = $db->prepare($query4); 
                    $result4 = $stmt4->execute($query_params4);

                    while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                        $jsonArrayItem['student_number'] = $row4['student_number'];
                        $jsonArrayItem['name'] = $row4['name'];
                        $jsonArrayItem['surname'] = $row4['surname'];
                        $jsonArrayItem['qauntity'] = 0;

                        array_push($output,$jsonArrayItem);
                    }
                }
                $track = false;
            }
        }
        print json_encode($output);
    }

    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
?>