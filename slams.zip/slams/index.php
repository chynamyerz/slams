<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" />

	<script src="js/jquery-1.12.4.js"></script>
  	<script src="js/jquery-ui.js"></script>
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		//PrettyPhoto
		jQuery(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});
		
		//BlackAndWhite
		$(window).load(function(){
			$('.client_img').BlackAndWhite({
				hoverEffect : true, // default true
				// set the path to BnWWorker.js for a superfast implementation
				webworkerPath : false,
				// for the images with a fluid width and height 
				responsive:true,
				// to invert the hover effect
				invertHoverEffect: false,
				// this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
				intensity:1,
				speed: { //this property could also be just speed: value for both fadeIn and fadeOut
					fadeIn: 300, // 200ms for fadeIn animations
					fadeOut: 300 // 800ms for fadeOut animations
				},
				onImageReady:function(img) {
					// this callback gets executed anytime an image is converted
				}
			});
		});
		
	</script>
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

 <!-- Login Modal -->
  <div class="modal fade" id="loginModal" role="dialog">
    <div class="modal-dialog modal-sm">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Sign In</h4>
        </div>
        <div class="modal-body">
            <form> 
                <h3 style="text-align: center;">Enter Your Credentials</h3> 
                <div class="form-group"> 
                    <label for="username" class="uname" data-icon="u" >Enter Username </label>
                    <input type="text" onPaste="return false" required name="username" placeholder="Username" class="form-control" ng-model="username" style="color:black;">
                </div>
                <div class="form-group"> 
                    <label for="password" class="youpasswd" data-icon="p">Enter Password</label>
                    <input type="password" onPaste="return false" required name="password" placeholder="Password" class="form-control" ng-model="password" style="color:black;"> 
                </div>
                <button ng-click="lectureLogin()" class="btn btn-success pull-left">Login</button>
                <button ng-click="forgotPassword()" class="btn btn-danger pull-right">Forgotten Password?</button>
            </form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
	<!-- HEADER -->
	<header>
		
		<!-- MENU BLOCK -->
		<div class="menu_block">
		
			<!-- CONTAINER -->
			<div class="container clearfix">
				
				<!-- LOGO -->
				<div class="logo pull-left">
					<a href="index.php" ><img src="images/logo.jpg" ></a>
				</div><!-- //LOGO -->
				
				<!-- SEARCH FORM -->
				<!--<div id="search-form" class="pull-right">
					<form method="get" action="#">
						<input type="text" name="Search" value="Search" onFocus="if (this.value == 'Search') this.value = '';" onBlur="if (this.value == '') this.value = 'Search';" />
					</form>
				</div>--><!-- SEARCH FORM -->
				
				<!-- MENU -->
				<div class="pull-right">
					<nav class="navmenu center">
						<ul>
							<li class="first active scroll_btn"><a href="#home" >Home</a></li>
							<li class="scroll_btn"><a href="#attendance">Attendance</a></li>
							<li class="scroll_btn"><a href="#about" >About Us</a></li>
							<li class="scroll_btn"><a href="#service" >Service</a></li>
							<li class="scroll_btn last"><a href="#contacts" >Contacts</a></li>
							<?php
								if(empty($_SESSION["username"])){
								?>
									<li>
									  <button type="button" class="btn btn-success" data-toggle="modal" data-target="#loginModal"><i class="fa fa-sign-in"></i>  Sign In</button> 
									</li>
								<?php

								}else{
									?>
									<li class="sub-menu">
										<a href="javascript:void(0);" style="color: #00bfff;"><?php echo $_SESSION['username']." ACTIVE" ?></a>
										<ul>
											<li><a href="day_attendance.php" >Day</a></li>
											<li><a href="week_attendance.php" >Week</a></li>
											<li><a href="month_attendance.php" >Month</a></li>
											<li><a href="semester_attendance.php" >Semester</a></li>
										</ul>
									</li>
									<li class="scroll_btn last">
										<form>
											<button class="btn btn-primary" ng-click="logout()">
												Logout
											</button>
										</form>
									</li>

									<?php
								}
							?>
							<!--<li class="sub-menu">
								<a href="javascript:void(0);" >Pages</a>
								<ul>
									<li><a href="blog.html" >Blog</a></li>
									<li><a href="blog-post.html" >Blog Post</a></li>
									<li><a href="portfolio-post.html" >Portfolio Single Work</a></li>
								</ul>
							</li>-->
						</ul>
					</nav>
				</div><!-- //MENU -->
			</div><!-- //MENU BLOCK -->
		</div><!-- //CONTAINER -->
	</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	
		<!-- HOME -->
		<section id="home" class="padbot0">
				
			<!-- TOP SLIDER -->
			<div class="flexslider top_slider">
				<ul class="slides">
					<li class="slide1">
						<div class="flex_caption1">
							<p class="title1 captionDelay2 FromTop" style="color: #00ffff;">Smart</p>
							<p class="title1 captionDelay4 FromTop" style="color: #00ffff;">Lecture</p>
							<p class="title1 captionDelay6 FromTop" style="color: #00ffff;">Attendance</p>
							<p class="title2 captionDelay7 FromBottom" style="color: #00ff40;">Monitoring System.</p>
						</div>
					</li>
					<li class="slide2">
						<div class="flex_caption1">
							<p class="title1 captionDelay6 FromLeft" style="color: #9932CC;">Monitor</p>
							<p class="title1 captionDelay4 FromLeft" style="color: #9932CC;">Attendance</p>
							<p class="title1 captionDelay2 FromLeft" style="color: #9932CC;">Efficiently</p>
						</div>
					</li>
					<li class="slide3">
						<div class="flex_caption1">
							<p class="title1 captionDelay1 FromBottom" style="color: #DC143C;">Compute</p>
							<p class="title1 captionDelay2 FromBottom" style="color: #DC143C;">Attendance</p>
							<p class="title1 captionDelay3 FromBottom" style="color: #DC143C;">Percentage</p>
						</div>
					</li>
				</ul>
			</div>
			<div id="carousel">
				<ul class="slides">
					<li><img src="images/slide1_bg.jpg" alt="" /></li>
					<li><img src="images/slide2_bg.jpg" alt="" /></li>
					<li><img src="images/slide3_bg.jpg" alt="" /></li>
				</ul>
			</div><!-- //TOP SLIDER -->
		</section><!-- //HOME -->

		<!-- ATTENDANCE -->
		<section id="attendance">

			<!-- CLEAN CODE -->
			<div class="cleancode_block">

				<!-- CONTAINER -->
				<div class="container" data-appear-top-offset="-200" data-animated="fadeInUp">
					<!-- prototyping heading  -->
					<div class="container-fluid col-md-6 col-md-offset-3" id="heading">
						<h1 style="color:white;"><strong>Smart Lecture Attendance Monitoring System</strong></h1>
					</div><!-- end of prototyping heading -->

					<div class="container-fluid col-md-8 col-md-offset-2" id="student-form">
						<form>
						    <div class="form-group">
							    <label for="student-number">Student Number:</label>
							    <input type="text" class="form-control" ng-model="student_number" name="student_number" id="student_number" placeholder="e.g 201212345" required pattern = "([0-9]{0,9})" maxlength = "9" title = "Must be at most 9 digits" onPaste="return false" style="color:black;">
						  	</div>
						  	<button ng-click="studentAttendance()" class="btn btn-primary">Submit</button>
						</form>
					</div><!-- end of the prototyping form -->
				</div>
			</div>
		</section><!-- //ATTENDANCE -->

		
		<!-- ABOUT -->
		<section id="about">
		<div><h2 style="text-align: center; margin-bottom: 2em;"><b>About SLAMS</b></h2></div>
			<!-- MULTI PURPOSE -->
			<div class="purpose_block">
				<!-- CONTAINER -->
				<div class="container">
					<!-- ROW -->
					<div class="row">
						<div class="container">
							<div class="col-lg-6 col-md-6 col-sm-6" data-appear-top-offset="-200" data-animated="fadeInLeft">
								<p style="font-size: 17px;">Smart lecture attendance monitoring system is the sysyem built for automating the students
								attendance register by using the Radio Frequency Identification technology.</p>
								<p style="font-size: 17px;">It main purpose is to capture student's id for the particular course and mark that
								student as attended the lecture if all the neccessary checkings pass...</p>
								<p style="font-size: 17px;">A lecture can monitor and compute the attendance percentage for the particuar course.</p>
							</div>
							
							<div class="col-lg-6 col-md-6 col-sm-6 ipad_img_in" data-appear-top-offset="-200" data-animated="fadeInRight">
								<img class="ipad_img1" src="images/about-img.jpg" alt="" />
							</div>
						</div>
					</div><!-- //ROW -->
				</div><!-- //CONTAINER -->
			</div><!-- //MULTI PURPOSE -->
		</section><!-- //ABOUT -->

		<!-- SERVICE -->
		<section id="service">
			<!-- CONTAINER -->
			<div class="container">
				<h2 style="text-align: center;"><b>SLAMS</b> Services</h2>
				
				<!-- SERVICE -->
				<div class="row recent_posts" data-appear-top-offset="-200" data-animated="fadeInUp">
					<div class="col-lg-4 col-md-4 col-sm-4 padbot30 post_item_block">
						<div class="post_item">
							<h3><strong><a href="set_attendance.php" style="color: red;">SET ATTENDANCE REGISTER</a></strong></h3>
							<div class="post_item_img">
								<p style="font-size: 17px;">Allows the lecturer to set the attendance register based on the weekly basis and whether it is a lecture register or a practical register. This register is set according to the course code which a lecturer lectures.
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 padbot30 post_item_block">
						<div class="post_item">
							<div class="post_item_img">
								<h3><strong><a href="week_attendance.php" style="color: red;" >Monitor Attendance Register</a></strong> </h3>
								<p style="font-size: 17px;">This allows the lecturer to effectively monitor the students attendance register. It give two view about the attendance register
									<ol>
										<li><strong>Data Table View:</strong>Which gives the students attendance register in a table format highlighting those who have poor attendance with a red color.
										</li>
										<li><strong>Graphical View</strong>Which gives the students attendance register in a graphical format showing percentages of each student. and calculating the average attendance.
										</li>
									</ol>
								</p>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 padbot30 post_item_block">
						<div class="post_item">
							<div class="post_item_img">
								<h3><strong><a href="modify_attendance.php" style="color: red;">Modify Attendance Register</a></strong></h3>
								<p style="font-size: 17px;">This gives the lecturers the ability to manually mark the student attendance the lecture in a case where the student forgot his or her student card but was present for that lecture period.
								</p>
							</div>
						</div>
					</div>
				</div><!-- RECENT POSTS -->
			</div><!-- //CONTAINER -->
		</section><!-- //NEWS -->
	</div><!-- //PAGE -->
	
	<!-- CONTACTS -->
	<section id="contacts">
	</section><!-- //CONTACTS -->
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			
			<!-- ROW -->
			<div class="row" data-appear-top-offset="-200" data-animated="fadeInUp">
				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30">
					<h4><b>Contact Address</b></h4>
					
					<p style="font-size:18px;">South Arica <br>Kwa-Zulu Natal
					<br>Empangeni<br>University of Zulu Land<br>Kwadlangezwa Campus<br>3866</p>	
				</div>
				
				<div class="col-lg-4 col-md-4 col-sm-6 padbot30 foot_about_block">
					<h4>About <b>SLAMS</b></h4>
					<p style="font-size:18px;">A University of Zulu Land automated students attendance system.</p>
					<ul class="social">
						<li><a href="https://www.facebook.com/slamsunizulu/?skip_nax_wizard=true" ><i class="fa fa-facebook"></i></a></li>
					</ul>
				</div>
				
				<div class="respond_clear"></div>
				
				<div class="col-lg-4 col-md-4 padbot30">
					<h4><b>Contacts</b> SLAMS</h4>
					
					<!-- CONTACT FORM -->
					<div class="span5 contact_form">
						<div id="note"></div>
						<div id="fields">
							<form id="contact-form-face" class="clearfix">
								<input type="email" ng-model="email" name="Email Address" value="Email Address" onFocus="if (this.value == 'Email Address') this.value = '';" onBlur="if (this.value == '') this.value = 'Email Address';" required/>
								<textarea ng-model="message" name="message" onFocus="if (this.value == 'Message') this.value = '';" onBlur="if (this.value == '') this.value = 'Message';" required>Message</textarea>
								<input class="contact_btn" ng-click="sendMessage()" type="submit" value="Send message" />
							</form>
						</div>
					</div><!-- //CONTACT FORM -->
				</div>
			</div><!-- //ROW -->
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->
	
</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery-ui.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/FileSaver.js" type="text/javascript"></script>
<script src="js/Blob.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>