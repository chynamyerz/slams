angular
	.module('ng_App')
	.directive('datepicker', function(){
		return{
			require: 'ngModel',
			link: function(scope, element, attrs, ng_Controller){
				$(function(){
					element.datepicker({
						firstDay: 1,
						showButtonPanel: true,
						minDate: '2016-02-01',
						maxDate: '2016-11-30',
						dateFormat: 'yy-mm-dd',
						showWeek: true,
						onSelect: function(date){
							scope.$apply(function(){
								ng_Controller.$setViewValue(date);
							});
						}
					});
				});
			}
		}
	})
	.controller('ng_Controller', function($scope, $http){
		//This is used to define all the controllers
		$scope.view_data = "";
		$scope.items = 10;
		$scope.exportData = function () {
			$scope.items = $scope.view_data.length;
			if($scope.items<=0){
				alert("The table is empty can not export");
			}else if($scope.items>0){
				var blob = new Blob([document.getElementById('exportable').innerHTML], {
		            type: "application/xls"
		        });
		        saveAs(blob, "Report.xls");
			}
			$scope.items = 10;
	    };

	    $scope.selectSize = function(){
	    	if($scope.exporting === "Current"){
	    		$scope.items = 10;
	    	}else if($scope.exporting === "All"){
	    		$scope.items = $scope.view_data.length;
	    	}
	    }
		//Set attendance venue
		$scope.setAttendance = function(){
		$http.post("data/set_attendanceVenue.php", {'venue':$scope.lecture_venue})
			.success(function(data){
				if (data.trim() === "Captured") {
					alert("Venue is set.");
					window.location.href = "setVenue.php";
				}
				else if (data.trim() === "Not Captured") {
					alert("Something went wrong!");
				}
			});
		};
		
		//Controller for getting all the venues from the database
		$scope.selectVenue = function(){
		$http.get("data/selectVenue.php")
			.success(function(data){
				$scope.venue = data;
			});
		};

		//Controller for getting all the courses from the database
		$scope.selectCourse = function(){
		$http.get("data/course.php")
			.success(function(data){
				$scope.courses = data;
			});
		};

		$scope.respond_insertRegisterFormat = "FALSE VALUE";
		//Controller for setting the register format for the specific course
		$scope.insertRegisterFormat = function($cc, $wn, $lp, $num){
		$http.post("data/register.php", {'course_code':$cc, 'week_number':$wn,'lec_or_prac':$lp, 'qauntity':$num})
			.success(function(data){
				if(data.trim() === "L Captured" || data.trim() === "P Captured"){
					$scope.respond_insertRegisterFormat = data;
					alert("Attendance register set successfuly");
					window.location.href = 'set_attendance.php';
				}else if(data.trim() === "L Not Captured" || data.trim() === "P Not Captured"){
					alert("Attendance register set failed. Please try again");
				}else if(data.trim() === "Empty"){
					alert("The number of lectures or practicals is required!");
				}
			});
		};

		//Controller for getting the quantity of the lectures or practicals either for a day, month, week or semester.
		$scope.selecRegisterHeading = function(){
		$http.post("data/register_heading.php", {'course_code': $scope.course_code,'month_number': $scope.month_number, 'week_number':$scope.week_number, 'attendance_date':$scope.view_date, 'semester':$scope.semester,'lec_or_prac':$scope.lec_or_prac})
			.success(function(data){
				$scope.headings = data;
			});
		};

		//Controller for viewing the attendance register for the specific course either for a day, month, week or semester.
		$scope.selectViewData = function(){
		$http.post("data/view_attendance.php", {'course_code': $scope.course_code, 'week_number':$scope.week_number, 'month_number':$scope.month_number,'attendance_date':$scope.view_date, 'semester':$scope.semester,'lec_or_prac':$scope.lec_or_prac })
			.success(function(data){
				$scope.view_data = data;
				if($scope.view_data.length>0){
					$scope.sum = 0;
					$scope.average = 0;
					for(var i=0; i< $scope.view_data.length; i++){
						$scope.sum = Number($scope.sum) + Number($scope.view_data[i].qauntity); 
					}
					$scope.average = Number($scope.sum)/Number($scope.view_data.length);

					//Call to function for heading the attendance register table. 
					$scope.selecRegisterHeading();
				}
				$scope.statisticView();
			});
		};

		//Controller for directing pages to the right file.
		$scope.attendanceFormatView = function(){
			if($scope.attendance_view === "Day"){
				window.location.href = 'day_attendance.php';
			}else if($scope.attendance_view === "Week"){
				window.location.href = 'week_attendance.php';
			}else if($scope.attendance_view === "Month"){
				window.location.href = 'month_attendance.php';
			}else if($scope.attendance_view === "Semester"){
				window.location.href = 'semester_attendance.php';
			}
		};

		//Making the fusion chart properties be visible globally for access on the view side
		$scope.myDataSource = {};
		//Controller for the statistical analysis
		$scope.statisticView = function(){
			$http.post("data/view_statistic.php", {'course_code': $scope.course_code,'month_number': $scope.month_number, 'week_number':$scope.week_number, 'attendance_date':$scope.view_date, 'semester':$scope.semester,'lec_or_prac':$scope.lec_or_prac})
			.success(function(week_data){
				$scope.w_data = week_data;
				$scope.caption = "";
				$scope.subCaption = "";
				if($scope.view_date){
					$scope.caption = "Day Percentage vs Student";
					$scope.subCaption = "Students Day Attendance Analysis";
				}
				else if ($scope.week_) {
					$scope.caption = "Week Percentage vs Student";
					$scope.subCaption = "Students Week Attendance Analysis";
				}else if ($scope.month_) {
					$scope.caption = "Month Percentage vs Student";
					$scope.subCaption = "Students Month Attendance Analysis";
				}else{
					$scope.caption = "Semester Percentage vs Student";
					$scope.subCaption = "Students Semester Attendance Analysis";
				}
				
				$scope.myDataSource = {
	                chart: {
	                    caption: $scope.caption,
	                    subCaption: $scope.subCaption,
	                    yaxisname: "Percentage(%)",
	                    xaxisname: "Students",
	                    baseFont: "Verdana",
				        baseFontSize: "12",
				        baseFontColor: "#55AA00",
					    captionFont: "Arial",
				        captionFontSize: "30",
				        captionFontColor: "#993300",
				        captionFontBold: "1",
				        subcaptionFont: "Arial",
				        subcaptionFontSize: "20",
				        subcaptionFontColor: "#993300",
				        subcaptionFontBold: "0",
	                    adjustDiv:'0',
	                    numDivLines: "9",
	                    formatNumberScale:'0',
	                    useRoundEdges:'1',
	                    labelDisplay:"rotate", 
	                    slantLabels:"1",
	                    useEllipsesWhenOverflow: "1",
				        numbersuffix: "%",
				        yaxismaxvalue: "100",
				        rotatevalues: "1",
				        valueFontColor: "#000000",
				        valueFontSize: "12",
				        valueFontBold: "1",
				        valueFontItalic: "0",
				        theme: "zune",
				        palettecolors: "#0075c2",
				        exportEnabled: "1"
	                },
	                data:$scope.w_data
	            };
			});
		}; 

		//Controller for capturing the students attendance
		$scope.studentAttendance = function(){
			$http.post("data/rfid_attendance.php", {'student_number':$scope.student_number})
			.success(function(data){

				if (data.trim() === "Captured") {
					alert("Captured as attended this lecture.");
				}
				else if (data.trim() === "Not Captured") {
					alert("Something went wrong, not captured.");
				}
				else if (data.trim() === "Already Exist") {
					elert("Already captured as attended this lecture.");
					window.location.href = "index.php";
				}
				else if (data.trim() === "Not registerd") {
					alert("You are not registerd for this lecture");
				}
				else if (data.trim() === "No lecture") {
					alert("This venue has no lecture at this time");
				}
				else if (data.trim() === "Empty") {
					alert("Student number must be entered.");
				}
				else if(data.trim() === "Wait"){
					alert("Wait for a lecturer to activate attendance register.");
				}else{

				}
			});
		};
		
		$scope.sendMessage = function(){
			$http.post("data/send_mail.php", {'email': $scope.email,'text': $scope.message})
			.success(function(data) {
				if(data.trim() === "Success"){
					alert("Message sent successfuly. You will be contacted soon!");
				}else if(data.trim() === "No Success"){
					alert("Message not sent. Please try again later.");
				}
			});
		}

		//Controller for loading the forgotten password page
		$scope.forgotPassword = function(){
			window.location.href = "forgot_password.php"
		}
		
		//Controller for now controlling the set password.
		$scope.resetPassword = function(){
			$http.post("data/recover_password.php", {'username': $scope.username})
			.success(function(data) {
				$scope.respond = data;
				alert("This is for testing purposes since working offline\n" + $scope.respond[0].error_pss)
				if($scope.respond[0].error_msg === "Success"){
					alert("Password recovered. Please Check your email used for this website.");
					window.location.href = "index.php";
				}else if($scope.respond[0].error_msg === "No Success"){
					alert("Recovery failled. Please try again later.\n" + $scope.respond[0].error_pss);
				}
			});
		}
		//Controller for handling the login authentications and validations 
		$scope.lectureLogin = function(){
			$scope.user;
		$http.post("data/lecture_login.php", {'username': $scope.username,'password': $scope.password})
			.success(function(data) {
				if( data.trim() === $scope.username && (data.trim() !== "admin" && data.trim() !== "admin1" && data.trim() !== "admin2" )) {
					window.location.href = 'set_attendance.php';
				}else if(data.trim() === $scope.username && (data.trim() === "admin" || data.trim() === "admin1" || data.trim() === "admin2" )){
					window.location.href = 'crud/admin_home.php';
					
				}else{
					alert("Please enter correct credentials");
				}
			})
			.error(function() {
				alert("Invalid");
			});
		};

		//Controller for handling the logout function.
		$scope.logout = function(){
			$http.get("data/logout.php")
			.success(function(data){
				if (data.trim() === "Logged out") {
					window.location.href = 'index.php';
				}else{
					alert("Not loged out");
				}
			})
			.error(function(){
				alert("Bad Logout");
			});
		};
});