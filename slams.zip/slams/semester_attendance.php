<?php
	session_start();
	//Maintaining the user session. if the user is not logged in then redirect to log in page.
	if(isset($_SESSION['username']) == ''){
?>
	<script>
		alert("You must login first");
		window.location.href = "index.php";
	</script>
<?php
		
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" />

	<script src="js/jquery-1.12.4.js"></script>
  	<script src="js/jquery-ui.js"></script>
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		//PrettyPhoto
		jQuery(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});
		
		//BlackAndWhite
		$(window).load(function(){
			$('.client_img').BlackAndWhite({
				hoverEffect : true, // default true
				// set the path to BnWWorker.js for a superfast implementation
				webworkerPath : false,
				// for the images with a fluid width and height 
				responsive:true,
				// to invert the hover effect
				invertHoverEffect: false,
				// this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
				intensity:1,
				speed: { //this property could also be just speed: value for both fadeIn and fadeOut
					fadeIn: 300, // 200ms for fadeIn animations
					fadeOut: 300 // 800ms for fadeOut animations
				},
				onImageReady:function(img) {
					// this callback gets executed anytime an image is converted
				}
			});
		});
		
	</script>
	
</head>
<body ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
		<!-- HEADER -->
		<header>
			
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo pull-left">
						<a href="index.php" ><img src="images/logo.jpg" ></a>
					</div><!-- //LOGO -->
					
					<!-- MENU -->
					<div class="pull-right">
						<nav class="navmenu center">
							<ul>
								<li class="first active scroll_btn"><a href="index.php" >Home</a></li>
								<li class="scroll_btn"><a href="setVenue.php" >Set-Venue</a></li>
								<li class="scroll_btn"><a href="set_attendance.php" >Set-Register</a></li>
								<li class="sub-menu">
									<a href="javascript:void(0);" >Monitor-Register</a>
									<ul>
										<li><a href="day_attendance.php" >Day</a></li>
										<li><a href="week_attendance.php" >Week</a></li>
										<li><a href="month_attendance.php" >Month</a></li>
									</ul>
								</li>
								<li class="scroll_btn" ><a style="color: red; font-style: italic;">
									<?php
										echo $_SESSION["username"];
									?></a>
								</li>
								<li class="scroll_btn last">
									<form>
										<button class="btn btn-primary" ng-click="logout()">
											Logout  <i class="fa fa-sign-out"></i>
										</button> 
									</form>
								</li>
							</ul>
						</nav>
					</div><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	

		<section>
			<!-- view the attendance register for the particular course -->
			<div id="view_report" style="margin-top:5em; clear:both;">

				<div class="container">
					<div class="container col-md-4 col-md-offset-4">
						<h4 style="text-align:center;">Select To View Register</h4>
						<form>
						  	<div class="input-group">
								<span class="input-group-addon">Course</span>
								<select ng-model="course_code" ng-click="selectCourse()" ng-change="selectViewData()" class="form-control" required>
									<option ng-repeat="c in courses">{{c.course_code}}</option>
								</select>
							</div>
							<br>
							<div class="input-group">
								<span class="input-group-addon">Lec/Prac</span>
								<select ng-model="lec_or_prac" ng-change="selectViewData()" class="form-control" required>
									<option>Lectures</option>
									<option>Practicals</option>
								</select>
							</div>
							<br>
							<div class="input-group">
								<span class="input-group-addon">Semester</span>
								<select ng-model="semester" ng-change="selectViewData()" class="form-control" required>
									<option>s1</option>
									<option>s2</option>
								</select>
							</div>				
						</form>
				  		<!-- End of the form -->
					</div>
				</div>
				<!-- Student attendance register -->
				<div class="container-fluid" style="margin-left:1em; margin-right: 1em;">
					<div class="row pull-left">
						<div class="input-group col-lg-8 col-md-8 col-sm-8">
							<span class="input-group-addon">Size</span>
							<select ng-model="exporting" ng-change="selectSize()" class="form-control">
								<option selected="selected">Current</option>
								<option>All</option>
							</select>
						</div>
						<div class="col-lg-4 col-md-4 col-sm-4">
							<button class="btn btn-success" ng-click="exportData()">Export-Excel</button>
						</div>
					</div>
					<div id="exportable">
						<!-- Displaying student data from the data -->
					  	<table class="table table-bordered table-responsive table-striped">
						  	<thead>
						    	<tr>
						    		<th><strong>Student Number</strong></th>
						    		<th><strong>Name</strong></th>
						    		<th><strong>Surname</strong></th>
						    		<th ng-repeat="h in headings"><strong>{{lec_or_prac}} = {{h.qauntity}}</strong></th>
						    		<th ng-repeat="h in headings"><strong>Percentage = 100%</strong></th>
						    	</tr>
						  	</thead>
						    
						    <tbody>
						    	<tr dir-paginate="student in view_data | itemsPerPage: items ">
						    		<td>{{student.student_number}}</td>
						    		<td>{{student.name}}</td>
						    		<td>{{student.surname}}</td>
						    		<td>{{student.qauntity}}</td>
						    		<td ng-repeat="p in headings" ng-if="(student.qauntity/p.qauntity)*100 < 80" style="color: red;"><strong>{{(student.qauntity/p.qauntity)*100 | number:0 }}</strong></td>
						    		<td ng-repeat="p in headings" ng-if="(student.qauntity/p.qauntity)*100 >= 80" style="color: green;"><strong>{{(student.qauntity/p.qauntity)*100 | number:0 }}</strong></td>
						    	</tr>
						    	<tr style="color: black; font-style: bold italic; font-size: 18px;">
						    		<td style="color: blue;">Total Semester Attendance</td><td style="color: blue;">{{sum | number:2}}</td>
						    	</tr>
						    	<tr style="color: black; font-style: bold italic; font-size: 18px;">
						    		<td style="color: blue;">Average Semester Attendance</td><td style="color: blue;">{{average | number:2}}</td>
						    	</tr>
						    </tbody>
					  	</table>
					  	<div style="font-size: 15px;" class="text-center">
		            		<dir-pagination-controls max-size="5" direction-links="true" boundary-links="true" ></dir-pagination-controls>
		            	</div>
		            	<br><br>
					</div>
					
				</div>
				<!-- End student attendance register -->
			  	<!-- Attendance chart analysis -->
				<div class="container-fluid" style="margin-bottom:15em; margin-left:1em; margin-right: 1em;">
					<div>
						<fusioncharts width="100%" height="100%" type="column2d" datasource="{{myDataSource}}"></fusioncharts>
					</div>
				</div>
				<!-- End attendance chart analysis -->
			</div>
			
		</section>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->

</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/jquery-ui.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/FileSaver.js" type="text/javascript"></script>
<script src="js/Blob.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>