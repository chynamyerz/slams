<?php
	session_start();
	header("Refresh: 1800; setVenue.php");
	if(isset($_SESSION['username']) != ""){
		if(isset($_SESSION['lecturer']) !="" and isset($_SESSION['set_venue']) != "" and ((time() - $_SESSION['set_venue']) > 1800)){
		require("data/dbconnect.php");

			$lecture_id = $_SESSION['lecturer'];

			$query = "UPDATE lecture SET lecture_venue=:lecture_venue WHERE staff_id=:lecture_id ";
	        $query_params = array(':lecture_venue'=>"",':lecture_id'=>$lecture_id);   
	        $stmt = $db->prepare($query); 
	        $result = $stmt->execute($query_params);
		}
	}else{
		?>
			<script>
				alert("You must login first");
				window.location.href = "index.php";
			</script>
		<?php
	}
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
	<!-- HEADER -->
		<header>
			
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo pull-left">
						<a href="index.php" ><img src="images/logo.jpg" ></a>
					</div><!-- //LOGO -->
					
					<!-- MENU -->
					<div class="pull-right">
						<nav class="navmenu center">
							<ul>
								<li class="first active scroll_btn"><a href="index.php" >Home</a></li>
								<li class="scroll_btn"><a href="set_attendance.php" >Set-Register</a></li>
								<li class="sub-menu">
									<a href="javascript:void(0);" >Monitor-Register</a>
									<ul>
										<li><a href="day_attendance.php" >Day</a></li>
										<li><a href="week_attendance.php" >Week</a></li>
										<li><a href="month_attendance.php" >Month</a></li>
										<li><a href="semester_attendance.php" >Semester</a></li>
									</ul>
								</li>
								<li class="scroll_btn" ><a style="color: red; font-style: italic;">
									<?php
										echo $_SESSION["username"];
									?></a>
								</li>
								<li class="scroll_btn last">
									<form>
										<button class="btn btn-primary" ng-click="logout()">
											Logout  <i class="fa fa-sign-out"></i>
										</button>
									</form>
								</li>
							</ul>
						</nav>
					</div><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	
		<!--Admin Sign-In -->
		<section id="about">
			<div class="container-fluid col-md-4 col-md-offset-4" id="student-form">
				<h3>Set Lecture Venue To Auto-activate Register</h3>
				<form>
				  	<div class="input-group">
						<span class="input-group-addon">Select Venue</span>
						<select ng-model="lecture_venue" ng-click="selectVenue()" class="form-control">
							<option ng-repeat="v in venue">{{v.room_number}}</option>
						</select>
					</div>
					
					<div>
						<br>
						<input ng-click="setAttendance()" class="btn btn-success" value="Set Venue">
					</div>				
				</form>
			</div><!-- end of the prototyping form -->
		</section>
	</div>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->
	
</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>


<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>