<?php
    session_start();
    if(isset($_SESSION['admin']) == ''){
    	echo "<script>alert('You must login first!');</script>";
    	header("Refresh:0; index.php");
    }
?>

<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		
	</script>
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
	<!-- HEADER -->
	<header>
		
		<!-- MENU BLOCK -->
		<div class="menu_block">
		
			<!-- CONTAINER -->
			<div class="container clearfix">
				
				<!-- LOGO -->
				<div class="logo pull-left">
					<a href="index.php" ><img src="images/logo.jpg" ></a>
				</div><!-- //LOGO -->
				
				<!-- MENU -->
				<div class="pull-right">
					<nav class="navmenu center">
						<ul>
							<li class="first active scroll_btn"><a href="#home" >Home</a></li>
							<li class="scroll_btn last">
								<form>
									<button class="btn btn-primary" ng-click="logout()">
										Logout
									</button>
								</form>
							</li>
						</ul>
					</nav>
				</div><!-- //MENU -->
			</div><!-- //MENU BLOCK -->
		</div><!-- //CONTAINER -->
	</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">

		<section>
			<div class="container">
				<div class="container-fluid col-md-6 col-md-offset-3" id="student-form">
					<div class="row">
		    			<h2 style="text-align: center; margin-top: 1em;">Add Student Record</h2>
		    		</div>
			
					<form>
					    <div class="form-controls">
					    	<label class="control-label">Student Number</label>
					      	<input ng-model="student_number" type="text"  placeholder="Student Number" style="color:black;">
					    </div>
					  
					    <div class="form-controls">
					    	<label class="control-label">First Name</label>

					      	<input ng-model="fname" type="text" placeholder="First Name" style="color:black;">
					    </div>
					  
					    <div class="form-controls">
					    	<label class="control-label">Last Name</label>

					      	<input ng-model="lname" type="text"  placeholder="Last Name" style="color:black;">
					    </div>
					  
					  	<div>
						    <input ng-click="crudCreate()" class="btn btn-success" value="Create">
						</div>
					</form>
				
				</div>		
		    </div> <!-- /container -->

		</section>>
		<!-- CONTACTS -->
		<section id="contacts">
		</section><!-- //CONTACTS -->	
	</div>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->
	
</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>


<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>