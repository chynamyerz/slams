<?php

	require('dbconnect.php');

	//get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));
    if(!empty($data->action) and $data->action == "Students"){
        if(!empty($data->student_number) and !empty($data->fname) and !empty($data->lname)){
            $student_number = $data->student_number;
            $fname = $data->fname;
            $lname = $data->lname;

            $query = "UPDATE student SET student_number=:student_number, name=:name, surname=:surname WHERE student_number=:student_number ";

            $query_params = array(':student_number'=>$student_number,':name'=>$fname, ':surname' =>$lname);
            
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params);

            if($result){
                echo "Success";
            }else{
                echo "No Success";
            }
        }else{
            if(empty($data->student_number)){
                echo "Student Number Empty";
            }else if(empty($data->fname)){
                echo "Student Name Empty";
            }else if(empty($data->lname)){
                echo "Student Surname Empty";
            }
        }
    }
    elseif (!empty($data->action) and $data->action == "Staffs") {
        if(!empty($data->staff_number) and !empty($data->fname) and !empty($data->lname)){
            $staff_number = $data->staff_number;
            $fname = $data->fname;
            $lname = $data->lname;
            $passwod = $data->passwod;

            $query = "UPDATE lecture SET staff_id=:staff_number, name=:name, surname=:surname WHERE staff_id=:staff_number ";

            $query_params = array(':staff_number'=>$staff_number, ':name'=>$fname, ':surname' =>$lname);
            
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params);

            if($result){
                echo "Success";
            }else{
                echo "No Success";
            }
        }else{
            if(empty($data->staff_number)){
                echo "Staff Number Empty";
            }else if(empty($data->fname)){
                echo "Staff Name Empty";
            }else if(empty($data->lname)){
                echo "Staff Surname Empty";
            }
        }
    }
	
?>