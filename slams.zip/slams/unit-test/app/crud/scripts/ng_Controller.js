angular
	.module('ng_App')
	.controller('ng_Controller', function($scope, $http){
		//This is used to define all the controllers

		//Controller for getting all the students from the database
		$scope.selectStudents = function(value){
		$http.post("php/crud_home.php", {'action': value})
			.success(function(data){
				$scope.allStudents = data;
			});
		};

		//Controller for getting all the staffs from the database
		$scope.selectStaffs = function(value){
		$http.post("php/crud_home.php", {'action': value})
			.success(function(data){
				$scope.allStaffs = data;
			});
		};

		//Controller for choosing who to administartor.
		$scope.directPage = function(page){
			if(page === "Students"){
				window.location.href = 'student_admin.php';
			}else if(page === "Staffs"){
				window.location.href = 'staff_admin.php';
			}
		};

		//Controler for adding student data on the database
		$scope.crudCreate = function(value){
		$http.post("php/crud_create.php", {'action':value, 'staff_number':$scope.staff_number, 'student_number': $scope.student_number, 'fname': $scope.fname, 'lname':$scope.lname})
			.success(function(data){
				if(value === "Students"){
					if(data.trim() === "Success"){
						alert('Record Added Successfully!');
						window.location.href = 'student_admin.php';
					}else if(data.trim() === "No Success"){
						alert('Error Adding Record. Please try again');
					}else if(data.trim() === "Already Exist"){
						alert('Already exist. Please go search for it.');
					}else if(data.trim() === "Student Number Empty"){
						alert('Student Number is required!');
					}else if(data.trim() === "Student Name Empty"){
						alert('Name is required!');
					}else if(data.trim() === "Student Surname Empty"){
						alert('Surname is required!');
					}
				}
				else if(value === "Staffs"){
					if(data.trim() === "Success"){
						alert('Record Added Successfully!');
						window.location.href = 'staff_admin.php';
					}else if(data.trim() === "No Success"){
						alert('Error Adding Record. Please try again');
					}else if(data.trim() === "Already Exist"){
						alert('Already exist. Please go search for it.');
					}else if(data.trim()=== "Staff Number Empty"){
						alert('Staff Number is required!');
					}else if(data.trim()=== "Staff Name Empty"){
						alert('Name is required!');
					}else if(data.trim()=== "Staff Surname Empty"){
						alert('Surname is required!');
					}
				}
			});
		};

		//Controller for reading student information
		$scope.readRecord = function(value, record){
			$http.post("php/crud_read.php", {'action': value, 'id':record})
			.success(function(data){
				$scope.recordInfo = data;
			});

		};

		//Controller for update modal information display
		$scope.updateModal = function(value, record){
			$http.post("php/crud_updateModal.php", {'action':value, 'id':record})
			.success(function(data){
				$scope.updateInfo = data;
			});
		};

		//Controller for updating student information
		$scope.updateRecord = function(value){
			var con = confirm("Are sure you want to update?");
			if(con == true){
				$http.post("php/crud_update.php", {'action':value, 'staff_number':$scope.updateInfo.staff_id, 'student_number':$scope.updateInfo.student_number, 'fname':$scope.updateInfo.name, 'lname':$scope.updateInfo.surname})
				.success(function(data){
					if(value === "Students"){
						if(data.trim() === "Success"){
							alert("Updated Successfully");
							window.location.href = 'student_admin.php';
						}else if(data.trim() === "No Success"){
							alert("Update failed. Please try again.");
						}else if(data.trim() === "Student Number Empty"){
							alert('Student Number is required!');
						}else if(data.trim() === "Student Name Empty"){
							alert('Student Name is required!');
						}else if(data.trim() === "Student Surname Empty"){
							alert('Student Surname is required!');
						}
					}else if(value === "Staffs"){
						if(data.trim() === "Success"){
							alert("Updated Successfully");
							window.location.href = 'staff_admin.php';
						}else if(data.trim() === "No Success"){
							alert("Update failed. Please try again.");
						}else if(data.trim() === "Staff Number Empty"){
							alert('Staff Number is required!');
						}else if(data.trim() === "Staff Name Empty"){
							alert('Staff Name is required!');
						}else if(data.trim() === "Staff Surname Empty"){
							alert('Staff Surname is required!');
						}
					}
				});
			}else if(confirm == false){
				window.location.href = 'student_admin.php';
			}
		};

		//Controller for deleting student information
		$scope.deleteRecord = function(value, record){
			var con = confirm("Are sure you want to delete?");
			if(con == true){
				$http.post("php/crud_delete.php", {'action':value, 'id':record})
				.success(function(data){
					if(value === "Students"){
						if(data.trim() === "Success"){
							alert("Record Deleted!");
							window.location.href = 'student_admin.php';
						}else if(data.trim() === "No Success"){
							alert("Deletion failed. Please try again.");
						}
					}else if(value === "Staffs"){
						if(data.trim() === "Success"){
							alert("Record Deleted!");
							window.location.href = 'staff_admin.php';
						}else if(data.trim() === "No Success"){
							alert("Deletion failed. Please try again.");
						}
					}
					
				});
			}else if(confirm == false){
				window.location.href = 'student_admin.php';
			}
		};

		//Controller for handling the login authentications and validations 
		$scope.adminLogin = function(){
		$http.post("php/admin_login.php", {'admin': $scope.admin,'password': $scope.password})
			.success(function(data) {

				if( data.trim() === $scope.admin) {
					window.location.href = 'admin_home.php';
				} else if(data.trim() === "Wrong Credentials"){
					alert("Please provide correct credentials");
				} else if(data.trim() === "Username Empty"){
					alert("Username is required");
				}else if(data.trim() === "Password Empty"){
					alert("Password is required");
				}
			})
			.error(function() {
				alert("Invalid");
			});
		};

		//Controller for handling the logout function.
		$scope.logout = function(){
			$http.get("php/logout.php")
			.success(function(data){
				if (data.trim() === "Logged out") {
					window.location.href = 'index.php';
				}else{
					alert("Not loged out");
				}
			})
			.error(function(){
				alert("Bad Logout");
			});
		};


		//Calling the above controller functions
		$scope.selectStudents("Students");
		$scope.selectStaffs("Staffs");
});