<?php
    session_start();
    if(isset($_SESSION['admin']) == ''){
    	echo "<script>alert('You must login first!');</script>";
    	header("Refresh:0; index.php");
    }
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
	<!-- HEADER -->
	<header>
		
		<!-- MENU BLOCK -->
		<div class="menu_block">
		
			<!-- CONTAINER -->
			<div class="container clearfix">
				
				<!-- LOGO -->
				<div class="logo pull-left">
					<a href="../index.html" ><img src="images/logo.jpg" ></a>
				</div><!-- //LOGO -->
				
				<!-- MENU -->
				<div class="pull-right">
					<nav class="navmenu center">
						<ul>
							<li class="first active scroll_btn"><a href="admin_home.php" >Home</a></li>
							<li class="scroll_btn"><a href="staff_admin.php" >Staffs</a></li>
							<li class="scroll_btn last">
								<form>
									<button class="btn btn-primary" ng-click="logout()">
										Logout
									</button>
								</form>
							</li>
						</ul>
					</nav>
				</div><!-- //MENU -->
			</div><!-- //MENU BLOCK -->
		</div><!-- //CONTAINER -->

		<!-- Create Modal -->
		<div class="modal fade" id="createModal" role="dialog">
		    <div class="modal-dialog modal-sm">
		    
		      	<!-- Modal content-->
		      	<div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title">Choose format</h4>
			        </div>
			        <div class="modal-body">
						<div class="container">
							<div class="container-fluid col-md-10 col-md-offset-1" id="student-form">
								<div class="row">
					    			<h2 style="text-align: center; margin-top: 1em;">Add Student Record</h2>
					    		</div>
						
								<form>
								    <div class="form-controls">
								    	<label class="control-label">Student Number</label>
								      	<input ng-model="student_number" type="text"  placeholder="Student Number" style="color:black;">
								    </div>
								  
								    <div class="form-controls">
								    	<label class="control-label">First Name</label>

								      	<input ng-model="fname" type="text" placeholder="Student Name" style="color:black;">
								    </div>
								  
								    <div class="form-controls">
								    	<label class="control-label">Last Name</label>
								      	<input ng-model="lname" type="text"  placeholder="Student Surname" style="color:black;">
								    </div>
								  
								  	<div>
									    <input ng-click="crudCreate('Students')" class="btn btn-success" value="Create">
									</div>
								</form>
							</div>		
					    </div> <!-- /container -->
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      </div>
		      
		    </div>
		</div><!-- //Create Modal -->

		<!-- Read Modal -->
		<div class="modal fade" id="readModal" role="dialog">
		    <div class="modal-dialog modal-sm">
		    
		      	<!-- Modal content-->
		      	<div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title">Choose format</h4>
			        </div>
			        <div class="modal-body">
			            <div class="container">
			            	<div class="row">
					    		<h3 style="text-align: center;padding-top: 0.5em;">Student Record</h3>
					    	</div>
							<div class="container-fluid col-md-6 col-md-offset-3" id="student-form">

							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 14px; ">Student Number:</span> {{recordInfo.student_number}}
							    	</label>
							      	
							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 14px; ">Name:</span> {{recordInfo.name}}
							    	</label>

							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">
							    		<span style="font-size: 14px; ">Surname:</span> {{recordInfo.surname}}
							    	</label>

							    </div>
							</div>		
					    </div> <!-- /container -->
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      </div>
		      
		    </div>
		</div><!-- //Read Modal -->

		<!-- Update Modal -->
		<div class="modal fade" id="updateModal" role="dialog">
		    <div class="modal-dialog modal-sm">
		    
		      	<!-- Modal content-->
		      	<div class="modal-content">
			        <div class="modal-header">
			          <button type="button" class="close" data-dismiss="modal">&times;</button>
			          <h4 class="modal-title">Choose format</h4>
			        </div>
			        <div class="modal-body">
			            <div class="container">
							<div class="container-fluid col-md-10 col-md-offset-1" id="student-form">
								<div class="row">
					    			<h3 style="text-align: center;">Update Student Record</h3>
					    		</div>

							    <div class="form-controls">
							    	<label class="control-label">Student Number</label>
							      	<input ng-model="updateInfo.student_number" type="text" style="color:black;">
							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">First Name</label>

							      	<input ng-model="updateInfo.name" type="text" style="color:black;">
							    </div>
							  
							    <div class="form-controls">
							    	<label class="control-label">Last Name</label>

							      	<input ng-model="updateInfo.surname" type="text" style="color:black;">
							    </div>
							  
							  	<div>
								    <button ng-click="updateRecord('Students')" class="btn btn-success">Submit</button>
								</div>
							</div>		
					    </div> <!-- /container -->
		        	</div>
		        	<div class="modal-footer">
		          		<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
		        	</div>
		      </div>
		      
		    </div>
		</div><!-- //Update Modal -->

	</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	

		<!--Admin controll -->
		<section>
			<div class="container">
		    	<div class="row">
		    		<h3>STUDENT CRUD</h3>
		    		</div>
					<div class="row">
						<p>
							<button class="btn btn-success" data-toggle="modal" data-target="#createModal">Create</button>
						</p>
						
						<table class="table table-striped table-bordered">
				            <thead>
				                <tr>
				                  <th><input type="text" style="padding: 0px; margin: 0px; color: black;" placeholder="Student Number" ng-model="search" class="form-controls"></th>
				                  <th>First Name</th>
				                  <th>Last Name</th>
				                  <th>Action</th>
				                </tr>
				            </thead>
				            <tbody>

					            <tr dir-paginate="student in allStudents | filter:search | itemsPerPage:10 ">
					            	<td>{{student.student_number}}</td>
					            	<td>{{student.name}}</td>
					            	<td>{{student.surname}}</td>
					            	<td width='250'>
					            		<button class="btn btn-primary" ng-click="readRecord('Students', student.student_number)" data-toggle="modal" data-target="#readModal">Read</button>
					            		<button class="btn btn-success" ng-click="updateModal('Students', student.student_number)" data-toggle="modal" data-target="#updateModal">Update</button>
					            		<button class="btn btn-danger" ng-click="deleteRecord('Students', student.student_number)">Delete</button>
					            	</td>
					            </tr>
						    </tbody>
			            </table>
			            <tfoot>
			            	<div style="font-size: 5px;" class="text-center">
			            		<dir-pagination-controls max-size="5" direction-links="true" boundary-links="true" ></dir-pagination-controls>
			            	</div>
			            	<br><br>
			            </tfoot>
		    		</div>
		    	</div>
		    </div> <!-- /container -->
		</section>

		<!-- CONTACTS -->
		<section id="contacts">
		</section><!-- //CONTACTS -->
	</div>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			</div><!-- //ROW -->
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->
	
</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/dirPagination.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>