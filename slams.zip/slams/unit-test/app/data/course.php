<?php
	session_start();

	require("dbconnect.php");

	$data = array();
	if (!empty($_SESSION['username'])) {
		//Retrieve data from the database of courses to be displayed for selection 
		//A SELECT query is used to retrieve data from the database. 
		$query = "SELECT * FROM course WHERE staff_id=:staff_id";

		$query_params = array(':staff_id'=>$_SESSION['username']);

	    $stmt = $db->prepare($query); 
	    $result = $stmt->execute($query_params); 

	    if($row = $stmt->fetchAll(PDO::FETCH_ASSOC)){
	        print json_encode($row);
	    }
	}
	
?>