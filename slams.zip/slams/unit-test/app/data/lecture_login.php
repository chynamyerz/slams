<?php
    session_start();
    //database settings
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    $output = array();

    if(!empty($data->username) and !empty($data->password)){
        $username = $data->username;
        $password = $data->password;

	    $query = "SELECT * FROM lecture WHERE staff_id=:username AND password=:password";

        $query_params = array(':username'=>$username, ':password'=>$password);

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 

        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            $_SESSION['username'] = $row['staff_id'];
            echo $_SESSION['username'];
        }
    }
?>