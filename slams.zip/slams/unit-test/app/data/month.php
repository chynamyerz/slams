<?php

	require("dbconnect.php");

	$data = array();

    //Retrieve data from the database of courses to be displayed for selection 
	//A SELECT query is used to retrieve data from the database. 
	$query = "SELECT * FROM month_year";
	
	foreach ($db->query($query) as $row) {
		$data[] = $row;
	}
	print json_encode($data);
?>