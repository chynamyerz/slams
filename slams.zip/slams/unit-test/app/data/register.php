<?php
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->qauntity) and !empty($data->week_number)){
        $course_code = $data->course_code;
        $week_number = $data->week_number;

        $date = $week_number;
        $check = new DateTime($date);
        $week_number = $check->format("W");
        $month_number = $check->format("m");

        $lec_or_prac= $data->lec_or_prac;
        $qauntity = $data->qauntity;

        if($lec_or_prac === "Lectures"){
            $query = 'INSERT INTO register_format (course_code, month, week, qauntity, lec_or_prac) 
                    VALUES(:course_code, :month_number, :week_number, :qauntity, :lec_or_prac)';

            $query_params = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':week_number'=>$week_number, ':qauntity'=>$qauntity, ':lec_or_prac'=>"L"); 

            try { 
                // Execute the query 
                $stmt = $db->prepare($query); 
                $result = $stmt->execute($query_params); 
            }catch(PDOException $ex) { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: Please provide valid information"); 
            } 

            if($result){
                echo "L Captured";
            }else{
                echo "L Not Captured";
            }

        }else if($lec_or_prac === "Practicals"){
            $query = 'INSERT INTO register_format (course_code, month, week, qauntity, lec_or_prac) 
                    VALUES(:course_code, :month_number, :week_number, :qauntity, :lec_or_prac)';

            $query_params = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':week_number'=>$week_number, ':qauntity'=>$qauntity, ':lec_or_prac'=>"P"); 

            try { 
                // Execute the query 
                $stmt = $db->prepare($query); 
                $result = $stmt->execute($query_params); 
            }catch(PDOException $ex) { 
                // Note: On a production website, you should not output $ex->getMessage(). 
                // It may provide an attacker with helpful information about your code.  
                die("Failed to run query: Please provide valid information"); 
            } 

            if($result){
                echo "P Captured";
            }else{
                echo "P Not Captured";
            }
        }
    }else{
        echo "Empty";
    }
?>