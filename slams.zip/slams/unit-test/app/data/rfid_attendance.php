<?php
	session_start();
	//database settings
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    if (!empty($data->student_number)) {
    	$student_number = $data->student_number;

    	$current_time = "11:30:30";//date("h:i:s"); 
    	$current_date = date("Y-m-d");
    	$current_day = "Friday";//date("l");
    	$lecture_id = $_SESSION['lecturer'];

    	$course_code = "";
    	$lec_or_prac = "";

    	$query = "SELECT lecture_venue FROM lecture WHERE staff_id=:lecture_id";

        $query_params = array(':lecture_id'=>$lecture_id);

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params);

        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
        	if($row['lecture_venue'] != ""){
        		$venue = $row['lecture_venue'];

        		$query = "SELECT course_code, lecture_or_practical FROM course_venue WHERE room_number=:venue AND time_in<=:time_in AND time_out>=:time_out AND day=:day ";

		        $query_params = array(':venue'=>$venue, ':time_in'=>$current_time, ':time_out'=>$current_time, ':day'=>$current_day);

		        $stmt = $db->prepare($query); 
		        $result = $stmt->execute($query_params); 

		        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
					$course_code = $row['course_code'];
		    		$lec_or_prac = $row['lecture_or_practical'];

		    		$query = "SELECT * FROM student_course WHERE student_number=:student_number AND course_code=:course_code ";

			        $query_params = array(':student_number'=>$student_number, ':course_code'=>$course_code);

			        $stmt = $db->prepare($query); 
			        $result = $stmt->execute($query_params);    	

			        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
			        	$query = "SELECT * FROM student_attendance WHERE student_number=:student_number AND course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";

				        $query_params = array(':student_number'=>$student_number, ':course_code'=>$course_code, ':attendance_date'=>$current_date, ':lec_or_prac'=>$lec_or_prac);

				        $stmt = $db->prepare($query); 
				        $result = $stmt->execute($query_params);
				        if($row = $stmt->fetch(PDO::FETCH_ASSOC)){
				        	echo "Already Exist";
				        }else{
				        	$query = 'INSERT INTO student_attendance (student_number, course_code, attendance_date, time_in, lecture_or_practical) 
		                        VALUES(:student_number, :course_code, :attendance_date, :time_in, :lec_or_prac)';

			                $query_params = array(':student_number'=>$student_number, ':course_code'=>$course_code, ':attendance_date'=>$current_date, ':time_in'=>$current_time, ':lec_or_prac'=>"L"); 

			                try { 
			                    // Execute the query 
			                    $stmt = $db->prepare($query); 
			                    $result = $stmt->execute($query_params); 
			                }catch(PDOException $ex) { 
			                    // Note: On a production website, you should not output $ex->getMessage(). 
			                    // It may provide an attacker with helpful information about your code.  
			                    die("Failed to run query: Please provide valid information"); 
			                } 

			                if($result){
			                    echo "Captured";
			                }else{
			                    echo "Not Captured";
			                }
				        }
			        }else{
			        	echo "Not registerd";
			        }
		        }else{
		        	echo "No lecture";
		        }
		    }else{
	        	echo "Wait";
	        }
        }
    }else{
    	echo "Empty";
    }

?>