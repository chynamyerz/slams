<?php
	//database settings
	require("dbconnect.php");

	$data = array();

    //Retrieve data from the venue database to be displayed for selection 
	//A SELECT query is used to retrieve data from the database. 
	$query = "SELECT * FROM venue";
	
	foreach ($db->query($query) as $row) {
		$data[] = $row;
	}
	print json_encode($data);
?>