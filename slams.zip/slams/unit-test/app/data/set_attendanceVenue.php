<?php
    session_start();
    //database settings
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    $output = array();

    if(!empty($data->venue)){
        $staff_id = $_SESSION['username'];
        $lecture_venue = $data->venue;
        
        $query = 'UPDATE lecture SET lecture_venue=:lecture_venue WHERE staff_id=:staff_id';

        $query_params = array(':lecture_venue'=>$lecture_venue, ':staff_id'=>$staff_id); 

        try { 
            // Execute the query 
            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
        }catch(PDOException $ex) { 
            // Note: On a production website, you should not output $ex->getMessage(). 
            // It may provide an attacker with helpful information about your code.  
            die("Failed to run query: Please provide valid information"); 
        } 

        if($result){
            $_SESSION['set_venue'] = time();
            $_SESSION['lecturer'] = $staff_id;
            echo "Captured";
        }else{
            echo "Not Captured";
        }
    }
?>