<?php
    //database settings
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    $output = array();
    //Attendance register for the specific day
    if(!empty($data->course_code) and !empty($data->attendance_date) and !empty($data->lec_or_prac)){
        $course_code = $data->course_code;
        $attendance_date = $data->attendance_date;
        $lec_or_prac = $data->lec_or_prac;

        if($lec_or_prac === "Lectures"){

            $query = "SELECT student_number FROM student_attendance WHERE course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':attendance_date'=>$attendance_date, ':lec_or_prac'=>"L");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $students = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = 1;

                    array_push($output,$jsonArrayItem);
                }
                
            }
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT student_number FROM student_attendance WHERE course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':attendance_date'=>$attendance_date, ':lec_or_prac'=>"P");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 
            $students = array();
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = 1;

                    array_push($output,$jsonArrayItem);
                }
                
            }
        }

        print json_encode($output);
    }
    //Attendance register for the specific week
    else if(!empty($data->course_code) and !empty($data->week_number) and !empty($data->lec_or_prac)){
        $course_code = $data->course_code;
        $week_number = $data->week_number;

        $date = $week_number;
        $check = new DateTime($date);
        $week_number = $check->format("W");

        $lec_or_prac = $data->lec_or_prac;

        if($lec_or_prac === "Lectures"){

            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_week = $check->format("W");
                
                if($attended_week==$week_number){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_week_attendance WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_week_attendance (student_number, course_code, week, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :week_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"L");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_week_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"L");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_week_attendance WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_week = $check->format("W");
                
                if($attended_week==$week_number){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_week_attendance WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_week_attendance (student_number, course_code, week, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :week_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"P");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_week_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':week_number'=>$week_number, ':count'=>$count, ':lec_or_prc'=>"P");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_week_attendance WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }
        print json_encode($output);
    }

    //Attendance register for the specific month
    else if(!empty($data->course_code) and !empty($data->month_number) and !empty($data->lec_or_prac)){
        $course_code = $data->course_code;
        $month_number = $data->month_number;
        $lec_or_prac = $data->lec_or_prac;

        if($lec_or_prac === "Lectures"){

            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_month = $check->format("m");
                
                if($attended_month==$month_number){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_month_attendance WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"L");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_month_attendance (student_number, course_code, month, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :month_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"L");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_month_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"L");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_month_attendance WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"L");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");

            $stmt = $db->prepare($query); 
            $result = $stmt->execute($query_params); 

            $temp_student = "";
            $count = 0;
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                $student_number = $row['student_number'];
                $date = $row['attendance_date'];
                $check = new DateTime($date);
                $attended_month = $check->format("m");
                
                if($attended_month==$month_number){
                    if($temp_student==$student_number) {
                        $count++;
                    }else{
                        $count = 1;
                    }

                    $query1 = "SELECT * FROM student_month_attendance WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

                    $query_params1 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"P");

                    $stmt1 = $db->prepare($query1); 
                    $result1 = $stmt1->execute($query_params1); 

                    if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC) == 0){
                        $query2 = "INSERT INTO student_month_attendance (student_number, course_code, month, qauntity, lec_or_prac) VALUES(:student_number, :course_code, :month_number, :count, :lec_or_prc)";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"P");
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }else{
                        $query2 = "UPDATE student_month_attendance SET qauntity=:count WHERE student_number=:student_number AND course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prc";
                        $query_params2 = array(':student_number'=>$student_number,':course_code'=>$course_code, ':month_number'=>$month_number, ':count'=>$count, ':lec_or_prc'=>"P");   
                        $stmt2 = $db->prepare($query2); 
                        $result2 = $stmt2->execute($query_params2);
                    }
                }
                

                $temp_student = $row['student_number'];
            }
            $query3 = "SELECT * FROM student_month_attendance WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";

            $query_params3 = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"P");

            $stmt3 = $db->prepare($query3); 
            $result3 = $stmt3->execute($query_params3); 

            while ($row3 = $stmt3->fetch(PDO::FETCH_ASSOC)){
                $query4 = "SELECT * FROM student WHERE student_number=:student_number";

                $query_params4 = array(':student_number'=>$row3['student_number']);

                $stmt4 = $db->prepare($query4); 
                $result4 = $stmt4->execute($query_params4);

                while($row4 = $stmt4->fetch(PDO::FETCH_ASSOC)){
                    $jsonArrayItem['student_number'] = $row4['student_number'];
                    $jsonArrayItem['name'] = $row4['name'];
                    $jsonArrayItem['surname'] = $row4['surname'];
                    $jsonArrayItem['qauntity'] = $row3['qauntity'];

                    array_push($output,$jsonArrayItem);
                }
            }
        }
        print json_encode($output);
    }
?>