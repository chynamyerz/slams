<?php
	//database settings
    require("dbconnect.php");

    //get the input data in jason format
    $data = json_decode(file_get_contents("php://input"));

    if(!empty($data->course_code) and !empty($data->attendance_date) and !empty($data->lec_or_prac)){
        $course_code = $data->course_code;
        $attendance_date = $data->attendance_date;
        $lec_or_prac = $data->lec_or_prac;
        $jsonArray = array();

        if($lec_or_prac === "Lectures"){

            $query = "SELECT * FROM student_attendance WHERE course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':attendance_date'=>$attendance_date, ':lec_or_prac'=>"L");

        }else if($lec_or_prac === "Practicals"){
            $query = "SELECT student_number FROM student_attendance WHERE course_code=:course_code AND attendance_date=:attendance_date AND lecture_or_practical=:lec_or_prac";

            $query_params = array(':course_code'=>$course_code, ':attendance_date'=>$attendance_date, ':lec_or_prac'=>"P");
        }

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 

        while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            //Converting the results into an associative array
            $jsonArrayItem = array();
            $jsonArrayItem['label'] = $row['student_number'];
            $jsonArrayItem['value'] = round(100);
            //append the above created object into the main array.
            array_push($jsonArray, $jsonArrayItem);
        }
        echo json_encode($jsonArray);


    }else if (!empty($data->course_code) and !empty($data->week_number) and !empty($data->lec_or_prac)) {
    	$jsonArray = array();
    	$output = 0;
    	
    	$course_code = $data->course_code;
        $week_number = $data->week_number;
        
        $date = $week_number;
        $check = new DateTime($date);
        $week_number = $check->format("W");

        $lec_or_prac = $data->lec_or_prac;

        if($lec_or_prac === "Lectures"){
        	$query1 = "SELECT * FROM register_format WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
            $query_params1 = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");

            $stmt1 = $db->prepare($query1); 
	        $result1 = $stmt1->execute($query_params1); 

	        if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
	            $output = $row1['qauntity'];
	        }

        	$query = "SELECT student_number, qauntity FROM student_week_attendance WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
        	$query_params = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"L");

        }else if($lec_or_prac === "Practicals"){
        	$query1 = "SELECT * FROM register_format WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
            $query_params1 = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");

            $stmt1 = $db->prepare($query1); 
	        $result1 = $stmt1->execute($query_params1); 

	        if($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
	            $output = $row1['qauntity'];
	        }

        	$query = "SELECT student_number, qauntity FROM student_week_attendance WHERE course_code=:course_code AND week=:week_number AND lec_or_prac=:lec_or_prac";
        	$query_params = array(':course_code'=>$course_code, ':week_number'=>$week_number, ':lec_or_prac'=>"P");
        }
    	
        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
		//check if there is any data returned by the SQL Query
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		  //Converting the results into an associative array
		    $jsonArrayItem = array();
		    $jsonArrayItem['label'] = $row['student_number'];
		    $jsonArrayItem['value'] = round(($row['qauntity']/$output)*100);
		    //append the above created object into the main array.
		    array_push($jsonArray, $jsonArrayItem);
		}
		echo json_encode($jsonArray);
	}else if(!empty($data->course_code) and !empty($data->month_number) and !empty($data->lec_or_prac)){
		$jsonArray = array();
    	$output = 0;
    	
    	$course_code = $data->course_code;
        $month_number = $data->month_number;
        $lec_or_prac = $data->lec_or_prac;

        if($lec_or_prac === "Lectures"){
        	$query1 = "SELECT * FROM register_format WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";
            $query_params1 = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"L");

            $stmt1 = $db->prepare($query1); 
	        $result1 = $stmt1->execute($query_params1); 

	        while($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
	            $output += $row1['qauntity'];
	        }


        	$query = "SELECT student_number, qauntity FROM student_month_attendance WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";
        	$query_params = array(':course_code'=>$course_code, ':month_number' =>$month_number, ':lec_or_prac'=>"L");

        }else if($lec_or_prac === "Practicals"){
        	$query1 = "SELECT * FROM register_format WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";
            $query_params1 = array(':course_code'=>$course_code, ':month_number'=>$month_number, ':lec_or_prac'=>"P");

            $stmt1 = $db->prepare($query1); 
	        $result1 = $stmt1->execute($query_params1); 

	        while($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
	            $output += $row1['qauntity'];
	        }

        	$query = "SELECT student_number, qauntity FROM student_month_attendance WHERE course_code=:course_code AND month=:month_number AND lec_or_prac=:lec_or_prac";
        	$query_params = array(':course_code'=>$course_code, ':month_number' =>$month_number, ':lec_or_prac'=>"P");
        }

        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
		        //check if there is any data returned by the SQL Query
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		  //Converting the results into an associative array
		    $jsonArrayItem = array();
		    $jsonArrayItem['label'] = $row['student_number'];
		    $jsonArrayItem['value'] = round(($row['qauntity']/$output)*100);
		    //append the above created object into the main array.
		    array_push($jsonArray, $jsonArrayItem);
		}
		echo json_encode($jsonArray);
	}else if(!empty($data->course_code) and !empty($data->lec_or_prac)){
		$jsonArray = array();
    	$output = 0;
    	
    	$course_code = $data->course_code;
        $lec_or_prac = $data->lec_or_prac;

        if($lec_or_prac === "Lectures"){
        	$query1 = "SELECT * FROM register_format WHERE course_code=:course_code AND lec_or_prac=:lec_or_prac";
            $query_params1 = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");

            $stmt1 = $db->prepare($query1); 
	        $result1 = $stmt1->execute($query_params1); 

	        while($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
	            $output += $row1['qauntity'];
	        }


        	$query = "SELECT student_number, qauntity FROM student_semester_attendance WHERE course_code=:course_code AND lec_or_prac=:lec_or_prac";
        	$query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"L");

        }else if($lec_or_prac === "Practicals"){
        	$query1 = "SELECT * FROM register_format WHERE course_code=:course_code AND lec_or_prac=:lec_or_prac";
            $query_params1 = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");

            $stmt1 = $db->prepare($query1); 
	        $result1 = $stmt1->execute($query_params1); 

	        while($row1 = $stmt1->fetch(PDO::FETCH_ASSOC)){
	            $output += $row1['qauntity'];
	        }

        	$query = "SELECT student_number, qauntity FROM student_month_attendance WHERE course_code=:course_code AND lec_or_prac=:lec_or_prac";
        	$query_params = array(':course_code'=>$course_code, ':lec_or_prac'=>"P");
        }
        $stmt = $db->prepare($query); 
        $result = $stmt->execute($query_params); 
		        //check if there is any data returned by the SQL Query
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
		  //Converting the results into an associative array
		    $jsonArrayItem = array();
		    $jsonArrayItem['label'] = $row['student_number'];
		    $jsonArrayItem['value'] = round(($row['qauntity']/$output)*100);
		    //append the above created object into the main array.
		    array_push($jsonArray, $jsonArrayItem);
		}
		echo json_encode($jsonArray);
	}
?>