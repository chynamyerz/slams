<?php
	session_start();
	//Maintaining the user session. if the user is not logged in then redirect to log in page.
	if(isset($_SESSION['username']) == ''){
?>
	<script>
		alert("You must login first");
		window.location.href = "index.html";
	</script>
<?php
		
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" />

	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  	<script>
  		$( function() {
    		$( "#datepicker" ).datepicker({
    			changeMonth: true,
    			changeYear: true,
      			firstDay: 1,
      			showButtonPanel: true,
      			minDate: '2016-01-01',
      			dateFormat: 'yy-mm-dd'
    		});
  		} );
  	</script>



<!--<script>

$(function() {


$("#datepicker").datepicker({
	minDate:'2016-01-01',
	dateFormat: 'yy-mm-dd',
	firstDay: 1,
changeMonth: true,
showAnim:'slideDown',

showButtonPanel: true,

showWeek: true

});


$(function() {


$("#datepicker").datepicker("option", "onSelect",

        function(value, date)

        { var week=$.datepicker.iso8601Week (

                new Date(date.selectedYear,

                        date.selectedMonth,

                        date.selectedDay));

         $(this).val(date.selectedYear+'-week-'+(week<10?'0':'')+week);

         

       }

 );


});

});

</script>-->

    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		//PrettyPhoto
		jQuery(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});
		
		//BlackAndWhite
		$(window).load(function(){
			$('.client_img').BlackAndWhite({
				hoverEffect : true, // default true
				// set the path to BnWWorker.js for a superfast implementation
				webworkerPath : false,
				// for the images with a fluid width and height 
				responsive:true,
				// to invert the hover effect
				invertHoverEffect: false,
				// this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
				intensity:1,
				speed: { //this property could also be just speed: value for both fadeIn and fadeOut
					fadeIn: 300, // 200ms for fadeIn animations
					fadeOut: 300 // 800ms for fadeOut animations
				},
				onImageReady:function(img) {
					// this callback gets executed anytime an image is converted
				}
			});
		});
		
	</script>
	
</head>
<body ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
		<!-- HEADER -->
		<header>
			
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo pull-left">
						<a href="index.html" ><img src="images/logo.jpg" ></a>
					</div><!-- //LOGO -->
					
					<!-- MENU -->
					<div class="pull-right">
						<nav class="navmenu center">
							<ul>
								<li class="first active scroll_btn"><a href="index.html" >Home</a></li>
								<li class="scroll_btn"><a href="setVenue.php" >Set-Venue</a></li>
								<li class="scroll_btn"><a href="set_attendance.php" >Set-Register</a></li>
								<li class="scroll_btn"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#monitorModal">Monitor-Register</button>
									<!-- Monitor Attendance Modal -->
								  <div class="modal fade" id="monitorModal" role="dialog">
								    <div class="modal-dialog modal-sm">
								    
								      <!-- Modal content-->
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">Choose format</h4>
								        </div>
								        <div class="modal-body">
								            <form> 
							                    <h3 style="text-align: center;">Select how to view attendance</h3> 
							                    <div class="form-group"> 
							                        <select ng-model="attendance_view" name="attendance_view" id="attendance_view" class="form-control">
														<!--<option>Semester</option>-->
														<option>Month</option>
														<option>Week</option>
													</select>
							                    </div>
							                    <button ng-click="attendanceFormatView()" class="btn btn-success">Submit</button>
							                </form>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								        </div>
								      </div>
								      
								    </div>
								  </div>
								</li>
								<li class="scroll_btn last">
									<form>
										<button class="btn btn-primary" ng-click="logout()">
											Logout
										</button>
									</form>
								</li>
							</ul>
						</nav>
					</div><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
		
	<!-- PAGE -->
	<div id="page">	

		<section>
			<div style="float:right; margin-right:1em; margin-top:1em;">
				<h3 style="padding:0px; margin:0px;">
					<?php 
						if (!empty($_SESSION['username'])) {
							echo $_SESSION['username'];
						}
					?>
				</h3>
				<p>Loged in</p>
			</div>
			<!-- view the attendance register for the particular course -->
			<div id="view_report" style="margin-top:5em; clear:both;">

				<div class="container-fluid">
					<div class="container">
						<h4 style="text-align:center;">Select the course, date and specify (Lecture/Practical) to view attendance</h4>
						<form>
						<table class="table table-bordered">
						  	<thead>
						    	<tr>
						    		<th>Course Code</th>
						    		<th>Date</th>
						    		<th>Lecture/Practical</th>
						    	</tr>
						  	</thead>
						    
						    <tbody>
						    	<div class="form-group">
									<tr>
										<td>	
											<select ng-model="course_code" name="course_code" id="course_code" class="form-control">
												<option ng-repeat="c in courses">{{c.course_code}}</option>
											</select>
										</td>

										<td>
											<input style="color: black;" type="text" ng-model="view_date" id="datepicker">
										</td>

										<td>
											<select ng-model="lec_or_prac" name="lec_or_prac" id="lec_or_prac" class="form-control">
												<option>Lectures</option>
												<option>Practicals</option>
											</select>
										</td>
									</tr>
								</div>
						    </tbody>
					  	</table>
					  	</form>
				  	<!-- End of the form -->
					</div>

					<!-- Student attendance register -->
					<div class="pull-left" style="margin-left:2em;">

						<button class="btn btn-success btn-block" ng-click="selectViewData()">View Student Attendance Register</button>
						
						<!-- Displaying student data from the data -->
					  	<table class="table table-bordered table-responsive">
						  	<thead>
						    	<tr>
						    		<th>Student Number</th>
						    		<th>Name</th>
						    		<th>Surname</th>
						    		<th ng-repeat="h in headings">{{lec_or_prac}} = {{h.qauntity}}</th>
						    		<th ng-repeat="h in headings">Percentage = 100%</th>
						    	</tr>
						  	</thead>
						    
						    <tbody>
						    	<tr ng-repeat="student in view_data">
						    		<td><strong>{{student.student_number}}</strong></td>
						    		<td><strong>{{student.name}}</strong></td>
						    		<td><strong>{{student.surname}}</strong></td>
						    		<td><strong>{{student.qauntity}}</strong></td>
						    		<td ng-repeat="p in headings"><strong>{{(student.qauntity/p.qauntity)*100 | number:0 }}</strong></td>
						    	</tr>
						    </tbody>
					  	</table>
					</div>
					<!-- End student attendance register -->
				  	<!-- Attendance chart analysis -->
					<div class="pull-right" style="margin-bottom:15em;margin-right:2em;">
						<button class="btn btn-warning btn-block" ng-click="statisticView()">View Student Attendance Graph Analysis</button>
						<fusioncharts width="600" height="400" type="column2d" datasource="{{myDataSource}}"></fusioncharts>
					</div>
					<!-- End attendance chart analysis -->
				</div>
			</div>
		</section>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->

</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/jquery-ui.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>