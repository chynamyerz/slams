
-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 10, 2016 at 10:57 AM
-- Server version: 5.1.61
-- PHP Version: 5.2.17

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `u999019832_slams`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`admin`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin`, `password`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `course_code` varchar(255) NOT NULL,
  `course_description` varchar(255) NOT NULL,
  `course_letter` varchar(255) NOT NULL,
  `staff_id` varchar(255) NOT NULL,
  PRIMARY KEY (`course_code`),
  KEY `course_code` (`course_code`),
  KEY `staff_id` (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_code`, `course_description`, `course_letter`, `staff_id`) VALUES
('scps112', 'Intro System Programming', 'B', ''),
('scps212', 'Intro Software Engineering', 'D', ''),
('scps312', 'Distributed System', 'E', 'Mba111'),
('scps322', 'Final Year Project', 'G', 'Mba111'),
('smth112', 'Calculus 2', 'F', ''),
('smth222', 'Linear Algebra', 'H', ''),
('sphy112', 'Electromagnetism and Nuclear Physics', 'A', ''),
('sphy212', 'Photonics and Waves', 'C', ''),
('sphy312', 'Nuclear Physics', 'H', ''),
('sphy322', 'Solid State & Material Science', 'F', '');

-- --------------------------------------------------------

--
-- Table structure for table `course_venue`
--

CREATE TABLE IF NOT EXISTS `course_venue` (
  `course_code` varchar(255) NOT NULL,
  `room_number` varchar(255) NOT NULL,
  `day` varchar(255) NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  `lecture_or_practical` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_venue`
--

INSERT INTO `course_venue` (`course_code`, `room_number`, `day`, `time_in`, `time_out`, `lecture_or_practical`) VALUES
('scps112', 'SC106', 'Monday', '08:30:00', '09:20:00', 'L'),
('scps112', 'SC106', 'Thursday', '10:30:00', '11:20:00', 'L'),
('scps112', 'SC106', 'Thursday', '11:30:00', '14:20:00', 'P'),
('scps112', 'SC106', 'Wednesday', '09:30:00', '10:20:00', 'L'),
('scps312', 'D3D4', 'Friday', '09:30:00', '10:20:00', 'L'),
('scps312', 'D3D4', 'Friday', '13:30:00', '16:30:00', 'P'),
('scps312', 'D3D4', 'Thursday', '07:30:00', '08:20:00', 'L'),
('scps312', 'D3D4', 'Tuesday', '08:30:00', '09:20:00', 'L'),
('scps322', 'D3D4', 'Friday', '11:30:00', '12:20:00', 'L'),
('scps322', 'D3D4', 'Monday', '11:30:00', '12:20:00', 'L'),
('scps322', 'D3D4', 'Wednesday', '10:30:00', '11:20:00', 'L'),
('scps322', 'D3D4', 'Wednesday', '14:20:00', '17:30:00', 'P'),
('smth112', 'SC101', 'Friday', '10:30:00', '11:20:00', 'L'),
('smth112', 'SC101', 'Monday', '10:30:00', '11:20:00', 'L'),
('smth112', 'SC101', 'Tuesday', '10:30:00', '11:20:00', 'L'),
('smth112', 'SC101', 'Tuesday', '14:30:00', '17:30:00', 'P'),
('sphy112', 'F17', 'Tuesday', '11:30:00', '14:20:00', 'P'),
('sphy112', 'SC106', 'Monday', '07:30:00', '08:20:00', 'L'),
('sphy112', 'SC106', 'Thursday', '08:30:00', '09:20:00', 'L'),
('sphy112', 'SC106', 'Tuesday', '09:30:00', '10:20:00', 'L'),
('sphy312', 'E9', 'Friday', '12:30:00', '13:20:00', 'L'),
('sphy312', 'E9', 'Monday', '12:30:00', '13:20:00', 'L'),
('sphy312', 'E9', 'Thursday', '10:30:00', '11:20:00', 'L'),
('sphy312', 'F9', 'Thursday', '14:30:00', '17:30:00', 'P'),
('sphy322', 'E9', 'Friday', '10:30:00', '11:20:00', 'L'),
('sphy322', 'E9', 'Monday', '10:30:00', '11:20:00', 'L'),
('sphy322', 'E9', 'Tuesday', '10:30:00', '11:20:00', 'L'),
('sphy322', 'F11', 'Tuesday', '14:30:00', '17:30:00', 'P');

-- --------------------------------------------------------

--
-- Table structure for table `lecture`
--

CREATE TABLE IF NOT EXISTS `lecture` (
  `staff_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`staff_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecture`
--

INSERT INTO `lecture` (`staff_id`, `name`, `surname`, `password`) VALUES
('Mba111', 'Ijoma', 'Mba', 'password'),
('Tawireyi110', 'Paul', 'Tarwireyi', 'password'),
('1234', 'Thami', 'Ndlovu', 'password');

-- --------------------------------------------------------

--
-- Table structure for table `month_year`
--

CREATE TABLE IF NOT EXISTS `month_year` (
  `id` int(11) NOT NULL,
  `month_` varchar(255) NOT NULL,
  PRIMARY KEY (`month_`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `month_year`
--

INSERT INTO `month_year` (`id`, `month_`) VALUES
(4, 'April'),
(8, 'August'),
(12, 'December'),
(2, 'February'),
(1, 'January'),
(7, 'July'),
(6, 'June'),
(3, 'March'),
(5, 'May'),
(11, 'November'),
(10, 'October'),
(9, 'September');

-- --------------------------------------------------------

--
-- Table structure for table `register_format`
--

CREATE TABLE IF NOT EXISTS `register_format` (
  `course_code` varchar(255) NOT NULL,
  `month` varchar(255) NOT NULL,
  `week` varchar(255) NOT NULL,
  `qauntity` int(10) NOT NULL,
  `lec_or_prac` varchar(100) NOT NULL,
  PRIMARY KEY (`course_code`,`month`,`week`,`lec_or_prac`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register_format`
--

INSERT INTO `register_format` (`course_code`, `month`, `week`, `qauntity`, `lec_or_prac`) VALUES
('scps322', '07', '30', 3, 'L'),
('scps322', '07', '29', 3, 'L'),
('scps322', '07', '28', 3, 'L'),
('scps312', '07', '29', 3, 'L'),
('scps322', '11', '46', 3, 'L');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `student_number` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `surname` varchar(255) NOT NULL,
  PRIMARY KEY (`student_number`),
  KEY `student_number` (`student_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_number`, `name`, `surname`) VALUES
('201329912', 'Siza Thubalethu', 'Africander'),
('201419433', 'Lindokuhle', 'Buthelezi'),
('200802804', 'Tswaki', 'Buthelezi'),
('201453793', 'Busisiwe Wendy', 'Chonco'),
('201328187', 'Bheki', 'Dlamini'),
('201253358', 'Thulani Henry', 'Dludla'),
('201417442', 'Nhlakanipho Cassim', 'Fakude'),
('201230401', 'Londeka Hope', 'Gumede'),
('201000209', 'Maxwell Thuthukani', 'Hlabisa'),
('201454796', 'Siyabonga Mxolisi', 'Jele'),
('201401902', 'Nontuthuko Innocentia Londeka', 'Khumalo'),
('201429920', 'Nothando Mbalenhle', 'Khuzwayo'),
('201453963', 'Celimpilo Siphamandla', 'Langa'),
('201258464', 'Mandla Jafithi', 'Mafuele'),
('201403624', 'Siyabonga Thulani', 'Mafuleka'),
('201454180', 'Nonduduzo Nokuthokomala Zamajoko', 'Makhoba'),
('201139667', 'Ntyatyambo', 'Mampofu'),
('201303753', 'Bonisiwe Nompilo', 'Maphalala'),
('201454126', 'Sizwe Jackson Clement', 'Masuku'),
('201318936', 'Siyathokoza Wiseman', 'Mathenjwa'),
('201138079', 'Mfundo Eugene', 'Mbatha'),
('201238289', 'Nothando Loveness Nomcebo', 'Mdletshe'),
('20035098', 'Aubrey Khayelihle', 'Mdluli'),
('201055510', 'Phumlani', 'Mdluli'),
('20033325', 'Manelisi Musawenkosi', 'Mgabi'),
('201328671', 'Nkosikhona', 'Mhlanga'),
('201258057', 'Sibonginkosi Kusaselihle Siyanda', 'Mhlongo'),
('201329329', 'Sipho Sihle', 'Mkhabela'),
('201450289', 'Nkanyiso', 'Mkhize'),
('201127132', 'Nonkululeko', 'Mkhwanazi'),
('201125071', 'Sizwe Sakhile', 'Mlambo'),
('201232048', 'Mpilo Clement', 'Mngomezulu'),
('201431061', 'Petros Smangaliso', 'Mnguni'),
('201306314', 'Ndumiso Philani', 'Mnikathi'),
('201227283', 'Wanda Gift', 'Mnomiya'),
('201242466', 'Nokuphila Khokheliwe', 'Mntungwa'),
('201310449', 'Amanda', 'Msomi'),
('201131721', 'Sandile Doctor', 'Msomi'),
('200902830', 'Sibongakonke Gift', 'Mthethwa'),
('201452906', 'Mxolisi David', 'Mtshali'),
('201317362', 'Nomonde', 'Myeni'),
('201120715', 'Sifiso', 'Myeza'),
('201256001', 'Xoliswa Fortunate', 'Mzelemu'),
('201328849', 'Maxine Delain', 'Naidoo'),
('201427891', 'Menzi Samkelo', 'Ndlovu'),
('201453235', 'Mthobisi Khethinkosi', 'Nduli'),
('201234927', 'Mthobisi Terence', 'Ngcobo'),
('201311082', 'Sibonelo', 'Ngcobo'),
('201425637', 'Sinenkosi Qaphela', 'Ngcobo'),
('201404957', 'Phindile Hlengiwe', 'Ngobese'),
('201402696', 'Nokubonga Future', 'Ngwane'),
('201259202', 'Vumani Moses', 'Nhlapo'),
('201239002', 'Minenhle Mnxolisi', 'Nkosi'),
('201225720', 'Nzaliseko', 'Nomabunga'),
('201327599', 'Bheka', 'Ntombela'),
('201319949', 'Malusi Mfanuvele', 'Ntombela'),
('201329100', 'Nombulelo Ntombikayise', 'Ntombela'),
('201132590', 'Siphesihle Sandile', 'Ntuli'),
('201161107', 'Nqobile Nodumo', 'Nxumalo'),
('201310064', 'Celenkosini Sibusiso', 'Nyawo'),
('201072050', 'Thobekile Happiness', 'Phakathi'),
('201450824', 'Zuzumusa Njabulo Sandiso', 'Sabela'),
('201454067', 'Dimpho Tholo', 'Selepe'),
('201314309', 'Wendy', 'Shazi'),
('201100794', 'Senzo Percival', 'Shozi'),
('201454558', 'Themba Cyril', 'Shozi'),
('201319652', 'Freedom Vikie', 'Sibanyoni'),
('201000611', 'Sfiso', 'Sibisi'),
('201323956', 'Nomthandazo', 'Sibiya'),
('201301340', 'Thembani', 'Sikhosana'),
('201329931', 'Petros Mfana', 'Simelane'),
('201414341', 'Senele Zwelitsha', 'Sithole'),
('201320809', 'Bongani', 'Xaba'),
('200951484', 'Ngweyakhe Vincent', 'Zakwe'),
('201432360', 'Thobeka Pretty', 'Zwane'),
('201123313', 'Nokwazi Portia', 'Biyela'),
('201403535', 'Mxolisi Nkosingiphile', 'Khoza'),
('201143876', 'Kopanang', 'Mabote'),
('201409213', 'Njabulo Sakhile', 'Mtetwa'),
('201053357', 'Givenson Thobani', 'Mwandla'),
('201317510', 'Menzi Meerfact', 'Ngcamphalala'),
('201302111', 'Ziphozonke Lindani Bhekinkosi', 'Qwabe'),
('201149200', 'Nelisiwe Eunice', 'Sihlangu'),
('201323777', 'Smangaliso Siyabonga', 'Zuma');

-- --------------------------------------------------------

--
-- Table structure for table `student_attendance`
--

CREATE TABLE IF NOT EXISTS `student_attendance` (
  `student_number` varchar(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `attendance_date` date NOT NULL,
  `time_in` time NOT NULL,
  `lecture_or_practical` varchar(255) NOT NULL,
  PRIMARY KEY (`student_number`,`course_code`,`attendance_date`,`lecture_or_practical`),
  KEY `student_number` (`student_number`),
  KEY `course_code` (`course_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_attendance`
--

INSERT INTO `student_attendance` (`student_number`, `course_code`, `attendance_date`, `time_in`, `lecture_or_practical`) VALUES
('201120715', 'scps312', '2016-08-01', '07:26:00', 'L'),
('201120715', 'scps312', '2016-08-03', '10:13:00', 'L'),
('201120715', 'scps322', '2016-07-11', '11:36:00', 'L'),
('201120715', 'scps322', '2016-07-12', '10:40:00', 'L'),
('201120715', 'scps322', '2016-07-18', '11:31:28', 'L'),
('201120715', 'scps322', '2016-07-19', '11:34:17', 'L'),
('201120715', 'scps322', '2016-07-26', '10:13:26', 'L'),
('201452906', 'scps322', '2016-07-11', '10:23:00', 'L'),
('201452906', 'scps322', '2016-07-13', '13:20:00', 'L'),
('201452906', 'scps322', '2016-07-15', '11:40:00', 'L'),
('201454558', 'scps322', '2016-07-11', '11:40:00', 'L'),
('201454558', 'scps322', '2016-07-13', '10:40:00', 'L'),
('201454126', 'scps322', '2016-07-15', '10:32:00', 'L'),
('201454126', 'scps322', '2016-07-11', '11:40:00', 'L');

-- --------------------------------------------------------

--
-- Table structure for table `student_course`
--

CREATE TABLE IF NOT EXISTS `student_course` (
  `student_number` varchar(255) NOT NULL,
  `course_code` varchar(255) NOT NULL,
  PRIMARY KEY (`student_number`,`course_code`),
  KEY `student_number` (`student_number`),
  KEY `course_code` (`course_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_course`
--

INSERT INTO `student_course` (`student_number`, `course_code`) VALUES
('20033325', 'SCPS322'),
('20035098', 'SCPS312'),
('20035098', 'SCPS322'),
('200802804', 'SCPS322'),
('200902830', 'SCPS322'),
('200951484', 'SCPS322'),
('201000209', 'SCPS322'),
('201000611', 'SCPS322'),
('201053357', 'SCPS312'),
('201055510', 'SCPS322'),
('201072050', 'SCPS322'),
('201100794', 'SCPS322'),
('201120715', 'SCPS312'),
('201120715', 'SCPS322'),
('201123313', 'SCPS312'),
('201125071', 'SCPS312'),
('201125071', 'SCPS322'),
('201127132', 'SCPS312'),
('201127132', 'SCPS322'),
('201131721', 'SCPS312'),
('201131721', 'SCPS322'),
('201132590', 'SCPS312'),
('201132590', 'SCPS322'),
('201138079', 'SCPS322'),
('201139667', 'SCPS312'),
('201139667', 'SCPS322'),
('201143876', 'SCPS312'),
('201149200', 'SCPS312'),
('201161107', 'SCPS322'),
('201225720', 'SCPS322'),
('201227283', 'SCPS312'),
('201227283', 'SCPS322'),
('201230401', 'SCPS322'),
('201232048', 'SCPS312'),
('201232048', 'SCPS322'),
('201234927', 'SCPS312'),
('201234927', 'SCPS322'),
('201238289', 'SCPS322'),
('201239002', 'SCPS312'),
('201239002', 'SCPS322'),
('201242466', 'SCPS312'),
('201242466', 'SCPS322'),
('201253358', 'SCPS312'),
('201253358', 'SCPS322'),
('201256001', 'SCPS322'),
('201258057', 'SCPS322'),
('201258464', 'SCPS312'),
('201258464', 'SCPS322'),
('201259202', 'SCPS322'),
('201301340', 'SCPS322'),
('201302111', 'SCPS312'),
('201303753', 'SCPS322'),
('201306314', 'SCPS312'),
('201306314', 'SCPS322'),
('201310064', 'SCPS312'),
('201310064', 'SCPS322'),
('201310449', 'SCPS322'),
('201311082', 'SCPS312'),
('201311082', 'SCPS322'),
('201314309', 'SCPS312'),
('201314309', 'SCPS322'),
('201317362', 'SCPS322'),
('201317510', 'SCPS312'),
('201318936', 'SCPS312'),
('201318936', 'SCPS322'),
('201319652', 'SCPS312'),
('201319652', 'SCPS322'),
('201319949', 'SCPS312'),
('201319949', 'SCPS322'),
('201320809', 'SCPS312'),
('201320809', 'SCPS322'),
('201323777', 'SCPS312'),
('201323956', 'SCPS312'),
('201323956', 'SCPS322'),
('201327599', 'SCPS312'),
('201327599', 'SCPS322'),
('201328187', 'SCPS312'),
('201328187', 'SCPS322'),
('201328671', 'SCPS322'),
('201328849', 'SCPS312'),
('201328849', 'SCPS322'),
('201329100', 'SCPS322'),
('201329329', 'SCPS312'),
('201329329', 'SCPS322'),
('201329912', 'SCPS322'),
('201329931', 'SCPS322'),
('201401902', 'SCPS322'),
('201402696', 'SCPS312'),
('201402696', 'SCPS322'),
('201403535', 'SCPS312'),
('201403624', 'SCPS322'),
('201404957', 'SCPS312'),
('201404957', 'SCPS322'),
('201409213', 'SCPS312'),
('201414341', 'SCPS312'),
('201414341', 'SCPS322'),
('201417442', 'SCPS312'),
('201417442', 'SCPS322'),
('201419433', 'SCPS312'),
('201419433', 'SCPS322'),
('201425637', 'SCPS322'),
('201427891', 'SCPS322'),
('201429920', 'SCPS312'),
('201429920', 'SCPS322'),
('201431061', 'SCPS312'),
('201431061', 'SCPS322'),
('201432360', 'SCPS322'),
('201450289', 'SCPS322'),
('201450824', 'SCPS322'),
('201452906', 'SCPS312'),
('201452906', 'SCPS322'),
('201453235', 'SCPS322'),
('201453793', 'SCPS322'),
('201453963', 'SCPS312'),
('201453963', 'SCPS322'),
('201454067', 'SCPS322'),
('201454126', 'SCPS312'),
('201454126', 'SCPS322'),
('201454180', 'SCPS322'),
('201454558', 'SCPS312'),
('201454558', 'SCPS322'),
('201454796', 'SCPS322');

-- --------------------------------------------------------

--
-- Table structure for table `student_month_attendance`
--

CREATE TABLE IF NOT EXISTS `student_month_attendance` (
  `student_number` varchar(50) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `month` varchar(50) NOT NULL,
  `qauntity` int(11) NOT NULL,
  `lec_or_prac` varchar(50) NOT NULL,
  PRIMARY KEY (`student_number`,`course_code`,`month`,`lec_or_prac`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_month_attendance`
--

INSERT INTO `student_month_attendance` (`student_number`, `course_code`, `month`, `qauntity`, `lec_or_prac`) VALUES
('201120715', 'scps322', '07', 5, 'L'),
('201452906', 'scps322', '07', 3, 'L'),
('201454558', 'scps322', '07', 2, 'L'),
('201454126', 'scps322', '07', 2, 'L');

-- --------------------------------------------------------

--
-- Table structure for table `student_semester_attendance`
--

CREATE TABLE IF NOT EXISTS `student_semester_attendance` (
  `student_number` varchar(50) NOT NULL,
  `course_code` varchar(50) NOT NULL,
  `qauntity` int(11) NOT NULL,
  `lec_or_prac` varchar(50) NOT NULL,
  PRIMARY KEY (`student_number`,`course_code`,`lec_or_prac`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_week_attendance`
--

CREATE TABLE IF NOT EXISTS `student_week_attendance` (
  `student_number` varchar(100) NOT NULL,
  `course_code` varchar(100) NOT NULL,
  `week` varchar(100) NOT NULL,
  `qauntity` int(11) NOT NULL,
  `lec_or_prac` varchar(100) NOT NULL,
  PRIMARY KEY (`student_number`,`course_code`,`week`,`lec_or_prac`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_week_attendance`
--

INSERT INTO `student_week_attendance` (`student_number`, `course_code`, `week`, `qauntity`, `lec_or_prac`) VALUES
('201120715', 'scps322', '28', 2, 'L'),
('201452906', 'scps322', '28', 3, 'L'),
('201454558', 'scps322', '28', 2, 'L'),
('201454126', 'scps322', '28', 2, 'L');

-- --------------------------------------------------------

--
-- Table structure for table `timetable_structure`
--

CREATE TABLE IF NOT EXISTS `timetable_structure` (
  `letter` varchar(5) NOT NULL,
  `day` varchar(50) NOT NULL,
  `time_in` time NOT NULL,
  `time_out` time NOT NULL,
  PRIMARY KEY (`letter`,`day`,`time_in`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable_structure`
--

INSERT INTO `timetable_structure` (`letter`, `day`, `time_in`, `time_out`) VALUES
('A', 'Monday', '07:30:00', '08:20:00'),
('A', 'Thursday', '08:30:00', '09:20:00'),
('A', 'Tuesday', '09:30:00', '10:20:00'),
('B', 'Monday', '08:30:00', '09:20:00'),
('B', 'Thursday', '09:30:00', '10:20:00'),
('B', 'Thursday', '11:30:00', '14:20:00'),
('B', 'Wednesday', '07:30:00', '08:20:00'),
('C', 'Friday', '07:30:00', '08:20:00'),
('C', 'Monday', '09:30:00', '10:20:00'),
('C', 'Wednesday', '08:30:00', '09:20:00'),
('D', 'Friday', '08:30:00', '09:20:00'),
('D', 'Tuesday', '07:30:00', '08:20:00'),
('D', 'Wednesday', '09:30:00', '10:20:00'),
('E', 'Friday', '09:30:00', '10:20:00'),
('E', 'Thursday', '07:30:00', '08:20:00'),
('E', 'Tuesday', '08:30:00', '09:20:00'),
('F', 'Friday', '10:30:00', '11:20:00'),
('F', 'Monday', '10:30:00', '11:20:00'),
('F', 'Tuesday', '10:30:00', '11:20:00'),
('G', 'Friday', '11:30:00', '12:20:00'),
('G', 'Monday', '11:30:00', '12:20:00'),
('G', 'Wednesday', '10:30:00', '11:20:00'),
('H', 'Friday', '12:30:00', '13:20:00'),
('H', 'Monday', '12:30:00', '13:20:00'),
('H', 'Thursday', '10:30:00', '11:20:00'),
('PA', 'Tuesday', '11:30:00', '14:20:00'),
('PB', 'Thursday', '11:30:00', '14:20:00'),
('PC', 'Monday', '13:30:00', '16:30:00'),
('PD', 'Wednesday', '11:30:00', '14:20:00'),
('PE', 'Friday', '13:30:00', '16:30:00'),
('PF', 'Tuesday', '14:30:00', '17:30:00'),
('PG', 'Wednesday', '14:30:00', '17:30:00'),
('PH', 'Tuesday', '14:30:00', '17:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `unizulu_calendar`
--

CREATE TABLE IF NOT EXISTS `unizulu_calendar` (
  `calendar_date` date NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`calendar_date`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unizulu_calendar`
--

INSERT INTO `unizulu_calendar` (`calendar_date`, `description`) VALUES
('2016-01-01', ''),
('2016-01-02', 'weekend'),
('2016-01-03', 'weekend'),
('2016-01-04', ''),
('2016-01-05', ''),
('2016-01-06', ''),
('2016-01-07', ''),
('2016-01-08', ''),
('2016-01-09', 'weekend'),
('2016-01-10', 'weekend'),
('2016-01-11', ''),
('2016-01-12', ''),
('2016-01-13', ''),
('2016-01-14', ''),
('2016-01-15', ''),
('2016-01-16', 'weekend'),
('2016-01-17', 'weekend'),
('2016-01-18', ''),
('2016-01-19', ''),
('2016-01-20', ''),
('2016-01-21', ''),
('2016-01-22', ''),
('2016-01-23', 'weekend'),
('2016-01-24', 'weekend'),
('2016-01-25', ''),
('2016-01-26', ''),
('2016-01-27', ''),
('2016-01-28', ''),
('2016-01-29', ''),
('2016-01-30', 'weekend'),
('2016-01-31', 'weekend'),
('2016-02-01', ''),
('2016-02-02', ''),
('2016-02-03', ''),
('2016-02-04', ''),
('2016-02-05', ''),
('2016-02-06', 'weekend'),
('2016-02-07', 'weekend'),
('2016-02-08', 'term1 start'),
('2016-02-09', ''),
('2016-02-10', ''),
('2016-02-11', ''),
('2016-02-12', ''),
('2016-02-13', 'weekend'),
('2016-02-14', 'weekend'),
('2016-02-15', ''),
('2016-02-16', ''),
('2016-02-17', ''),
('2016-02-18', ''),
('2016-02-19', ''),
('2016-02-20', 'weekend'),
('2016-02-21', 'weekend'),
('2016-02-22', ''),
('2016-02-23', ''),
('2016-02-24', ''),
('2016-02-25', ''),
('2016-02-26', ''),
('2016-02-27', 'weekend'),
('2016-02-28', 'weekend'),
('2016-02-29', ''),
('2016-03-01', ''),
('2016-03-02', ''),
('2016-03-03', ''),
('2016-03-04', ''),
('2016-03-05', 'weekend'),
('2016-03-06', 'weekend'),
('2016-03-07', ''),
('2016-03-08', ''),
('2016-03-09', ''),
('2016-03-10', ''),
('2016-03-11', ''),
('2016-03-12', 'weekend'),
('2016-03-13', 'weekend'),
('2016-03-14', ''),
('2016-03-15', ''),
('2016-03-16', ''),
('2016-03-17', ''),
('2016-03-18', ''),
('2016-03-19', 'weekend'),
('2016-03-20', 'weekend'),
('2016-03-21', 'holiday'),
('2016-03-22', ''),
('2016-03-23', 'term1 end'),
('2016-03-24', ''),
('2016-03-25', 'holiday'),
('2016-03-26', 'weekend'),
('2016-03-27', 'weekend'),
('2016-03-28', 'holiday'),
('2016-03-29', ''),
('2016-03-30', ''),
('2016-03-31', ''),
('2016-04-01', ''),
('2016-04-02', 'weekend'),
('2016-04-03', 'weekend'),
('2016-04-04', 'term2 star'),
('2016-04-05', ''),
('2016-04-06', ''),
('2016-04-07', ''),
('2016-04-08', ''),
('2016-04-09', 'weekend'),
('2016-04-10', 'weekend'),
('2016-04-11', ''),
('2016-04-12', ''),
('2016-04-13', ''),
('2016-04-14', ''),
('2016-04-15', ''),
('2016-04-16', 'weekend'),
('2016-04-17', 'weekend'),
('2016-04-18', ''),
('2016-04-19', ''),
('2016-04-20', ''),
('2016-04-21', ''),
('2016-04-22', ''),
('2016-04-23', 'weekend'),
('2016-04-24', 'weekend'),
('2016-04-25', ''),
('2016-04-26', ''),
('2016-04-27', 'holiday'),
('2016-04-28', ''),
('2016-04-29', ''),
('2016-04-30', 'weekend'),
('2016-05-01', 'weekend'),
('2016-05-02', ''),
('2016-05-03', ''),
('2016-05-04', ''),
('2016-05-05', ''),
('2016-05-06', ''),
('2016-05-07', 'weekend'),
('2016-05-08', 'weekend'),
('2016-05-09', ''),
('2016-05-10', ''),
('2016-05-11', ''),
('2016-05-12', ''),
('2016-05-13', ''),
('2016-05-14', 'weekend'),
('2016-05-15', 'weekend'),
('2016-05-16', ''),
('2016-05-17', ''),
('2016-05-18', ''),
('2016-05-19', 'term2 end'),
('2016-05-20', ''),
('2016-05-21', 'weekend'),
('2016-05-22', 'weekend'),
('2016-05-23', ''),
('2016-05-24', ''),
('2016-05-25', ''),
('2016-05-26', ''),
('2016-05-27', ''),
('2016-05-28', 'weekend'),
('2016-05-29', 'weekend'),
('2016-05-30', ''),
('2016-05-31', ''),
('2016-06-01', ''),
('2016-06-02', ''),
('2016-06-03', ''),
('2016-06-04', 'weekend'),
('2016-06-05', 'weekend'),
('2016-06-06', ''),
('2016-06-07', ''),
('2016-06-08', ''),
('2016-06-09', ''),
('2016-06-10', ''),
('2016-06-11', 'weekend'),
('2016-06-12', 'weekend'),
('2016-06-13', ''),
('2016-06-14', ''),
('2016-06-15', ''),
('2016-06-16', 'holiday'),
('2016-06-17', ''),
('2016-06-18', 'weekend'),
('2016-06-19', 'weekend'),
('2016-06-20', ''),
('2016-06-21', ''),
('2016-06-22', ''),
('2016-06-23', ''),
('2016-06-24', ''),
('2016-06-25', 'weekend'),
('2016-06-26', 'weekend'),
('2016-06-27', ''),
('2016-06-28', ''),
('2016-06-29', ''),
('2016-06-30', ''),
('2016-07-01', ''),
('2016-07-02', 'weekend'),
('2016-07-03', 'weekend'),
('2016-07-04', ''),
('2016-07-05', ''),
('2016-07-06', ''),
('2016-07-07', ''),
('2016-07-08', ''),
('2016-07-09', 'weekend'),
('2016-07-10', 'weekend'),
('2016-07-11', 'term3 start'),
('2016-07-12', ''),
('2016-07-13', ''),
('2016-07-14', ''),
('2016-07-15', ''),
('2016-07-16', 'weekend'),
('2016-07-17', 'weekend'),
('2016-07-18', ''),
('2016-07-19', ''),
('2016-07-20', ''),
('2016-07-21', ''),
('2016-07-22', ''),
('2016-07-23', 'weekend'),
('2016-07-24', 'weekend'),
('2016-07-25', ''),
('2016-07-26', ''),
('2016-07-27', ''),
('2016-07-28', ''),
('2016-07-29', ''),
('2016-07-30', 'weekend'),
('2016-07-31', 'weekend'),
('2016-08-01', ''),
('2016-08-02', ''),
('2016-08-03', ''),
('2016-08-04', ''),
('2016-08-05', ''),
('2016-08-06', 'weekend'),
('2016-08-07', 'weekend'),
('2016-08-08', 'holiday'),
('2016-08-09', 'holiday'),
('2016-08-10', ''),
('2016-08-11', ''),
('2016-08-12', ''),
('2016-08-13', 'weekend'),
('2016-08-14', 'weekend'),
('2016-08-15', ''),
('2016-08-16', ''),
('2016-08-17', ''),
('2016-08-18', ''),
('2016-08-19', 'term3 end'),
('2016-08-20', 'weekend'),
('2016-08-21', 'weekend'),
('2016-08-22', ''),
('2016-08-23', ''),
('2016-08-24', ''),
('2016-08-25', ''),
('2016-08-26', ''),
('2016-08-27', 'weekend'),
('2016-08-28', 'weekend'),
('2016-08-29', 'term4 start'),
('2016-08-30', ''),
('2016-08-31', ''),
('2016-09-01', ''),
('2016-09-02', ''),
('2016-09-03', 'weekend'),
('2016-09-04', 'weekend'),
('2016-09-05', ''),
('2016-09-06', ''),
('2016-09-07', ''),
('2016-09-08', ''),
('2016-09-09', ''),
('2016-09-10', 'weekend'),
('2016-09-11', 'weekend'),
('2016-09-12', ''),
('2016-09-13', ''),
('2016-09-14', ''),
('2016-09-15', ''),
('2016-09-16', ''),
('2016-09-17', 'weekend'),
('2016-09-18', 'weekend'),
('2016-09-19', ''),
('2016-09-20', ''),
('2016-09-21', ''),
('2016-09-22', ''),
('2016-09-23', ''),
('2016-09-24', 'weekend'),
('2016-09-25', 'weekend'),
('2016-09-26', ''),
('2016-09-27', ''),
('2016-09-28', ''),
('2016-09-29', ''),
('2016-09-30', ''),
('2016-10-01', 'weekend'),
('2016-10-02', 'weekend'),
('2016-10-03', ''),
('2016-10-04', ''),
('2016-10-05', ''),
('2016-10-06', ''),
('2016-10-07', ''),
('2016-10-08', 'weekend'),
('2016-10-09', 'weekend'),
('2016-10-10', ''),
('2016-10-11', ''),
('2016-10-12', ''),
('2016-10-13', ''),
('2016-10-14', 'term4 end'),
('2016-10-15', 'weekend'),
('2016-10-16', 'weekend'),
('2016-10-17', ''),
('2016-10-18', ''),
('2016-10-19', ''),
('2016-10-20', ''),
('2016-10-21', ''),
('2016-10-22', 'weekend'),
('2016-10-23', 'weekend'),
('2016-10-24', ''),
('2016-10-25', ''),
('2016-10-26', ''),
('2016-10-27', ''),
('2016-10-28', ''),
('2016-10-29', 'weekend'),
('2016-10-30', 'weekend'),
('2016-10-31', ''),
('2016-11-01', ''),
('2016-11-02', ''),
('2016-11-03', ''),
('2016-11-04', ''),
('2016-11-05', 'weekend'),
('2016-11-06', 'weekend'),
('2016-11-07', ''),
('2016-11-08', ''),
('2016-11-09', ''),
('2016-11-10', ''),
('2016-11-11', ''),
('2016-11-12', 'weekend'),
('2016-11-13', 'weekend'),
('2016-11-14', ''),
('2016-11-15', ''),
('2016-11-16', ''),
('2016-11-17', ''),
('2016-11-18', ''),
('2016-11-19', 'weekend'),
('2016-11-20', 'weekend'),
('2016-11-21', ''),
('2016-11-22', ''),
('2016-11-23', ''),
('2016-11-24', ''),
('2016-11-25', ''),
('2016-11-26', 'weekend'),
('2016-11-27', 'weekend'),
('2016-11-28', ''),
('2016-11-29', ''),
('2016-11-30', ''),
('2016-12-01', ''),
('2016-12-02', ''),
('2016-12-03', 'weekend'),
('2016-12-04', 'weekend'),
('2016-12-05', ''),
('2016-12-06', ''),
('2016-12-07', ''),
('2016-12-08', ''),
('2016-12-09', ''),
('2016-12-10', 'weekend'),
('2016-12-11', 'weekend'),
('2016-12-12', ''),
('2016-12-13', ''),
('2016-12-14', ''),
('2016-12-15', ''),
('2016-12-16', ''),
('2016-12-17', 'weekend'),
('2016-12-18', 'weekend'),
('2016-12-19', ''),
('2016-12-20', ''),
('2016-12-21', ''),
('2016-12-22', ''),
('2016-12-23', ''),
('2016-12-24', 'weekend'),
('2016-12-25', 'weekend'),
('2016-12-26', ''),
('2016-12-27', ''),
('2016-12-28', ''),
('2016-12-29', ''),
('2016-12-30', ''),
('2016-12-31', 'weekend');

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE IF NOT EXISTS `venue` (
  `room_number` varchar(255) NOT NULL,
  `building_name` varchar(255) NOT NULL,
  PRIMARY KEY (`room_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`room_number`, `building_name`) VALUES
('D3D4', 'D-Block'),
('E9', 'Physics Lecture Room'),
('F11', 'Physics Laboratory for Nuclear Physics'),
('F17', 'Physics Physics Laboratory'),
('F9', 'Physics Laboratory for Solid State & Material'),
('HP Lab 1', 'Computer Laboratory'),
('SC101', 'Science Lecture Room 101'),
('SC106', 'Science Lecture Room 106');

-- --------------------------------------------------------

--
-- Table structure for table `week_month`
--

CREATE TABLE IF NOT EXISTS `week_month` (
  `id` int(11) NOT NULL,
  `week_` varchar(255) NOT NULL,
  PRIMARY KEY (`week_`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `week_month`
--

INSERT INTO `week_month` (`id`, `week_`) VALUES
(1, 'Week-1'),
(2, 'Week-2'),
(3, 'Week-3'),
(4, 'Week-4');

-- --------------------------------------------------------

--
-- Table structure for table `week_of_month`
--

CREATE TABLE IF NOT EXISTS `week_of_month` (
  `month_of_year` varchar(255) NOT NULL,
  `week_of_month` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`month_of_year`,`week_of_month`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `week_of_month`
--

INSERT INTO `week_of_month` (`month_of_year`, `week_of_month`, `start_date`, `end_date`) VALUES
('August', 'Week-1', '2016-08-01', '2016-08-05'),
('August', 'Week-2', '2016-08-08', '2016-08-12'),
('August', 'Week-3', '2016-08-15', '2016-08-19'),
('August', 'Week-4', '2016-08-29', '2016-09-02'),
('July', 'Week-1', '2016-07-11', '2016-07-15'),
('July', 'Week-2', '2016-07-18', '2016-07-22'),
('July', 'Week-3', '2016-07-25', '2016-07-29'),
('September', 'Week-1', '2016-09-05', '2016-09-09'),
('September', 'Week-2', '2016-09-12', '2016-09-16'),
('September', 'Week-3', '2016-09-19', '2016-09-23');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
