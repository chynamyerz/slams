angular
	.module('ng_App')
	.controller('ng_Controller', function($scope, $http){
		//This is used to define all the controllers
		$scope.admin = function(){
			window.location.href = "crud/index.php";
		}

		$scope.responds = "no change";
		//Controller for setting the register format for the specific course
		$scope.insertRegisterFormat = function($c_c, $w_n, $l_p, $num){
		$http.post("data/register.php", {'course_code':$c_c, 'week_number':$w_n, 'lec_or_prac':$l_p, 'qauntity':$num })
			.success(function(data){
				$scope.responds = data.trim();
				if($scope.responds === "L Captured" || $scope.responds === "P Captured"){
					alert("Attendance register set successfuly");
					//window.location.href = 'set_attendance.php';
				}else if(data.trim() === "L Not Captured" || data.trim() === "P Not Captured"){
					alert("Attendance register set failed. Please try again");
				}else if(data.trim() === "Empty"){
					alert("The number of lectures or practicals is required!");
				}
			});
		}

		//Set attendance venue
		$scope.setAttendance = function(){
		$http.post("data/set_attendanceVenue.php", {'venue':$scope.lecture_venue})
			.success(function(data){
				if (data.trim() === "Captured") {
					alert("Venue is set.");
					window.location.href = "setVenue.php";
				}
				else if (data.trim() === "Not Captured") {
					alert("Something went wrong!");
				}
			});
		}

		//Controller for getting all the venues from the database
		$scope.selectVenue = function(){
		$http.get("data/selectVenue.php")
			.success(function(data){
				$scope.venue = data;
			});
		}
		//Controller for getting all the courses from the database
		$scope.selectCourse = function(){
		$http.get("data/course.php")
			.success(function(data){
				$scope.courses = data;
			});
		}
		//Controller for getting all the months from the database
		$scope.selectMonth = function(){
			$http.get("data/month.php")
				.success(function(data){
					$scope.months = data;
			});
		}
		//Controller for getting all the weeks from the database
		$scope.selectWeek = function(){
			$http.get("data/week.php")
				.success(function(data){
					$scope.weeks = data;
			});
		}

		//Controller for getting the quantity of the lectures or practicals either for a day, month, week or semester.
		$scope.selecRegisterHeading = function(){
		$http.post("data/register_heading.php", {'course_code': $scope.course_code,'month_number': $scope.month_number, 'week_number':$scope.week_number, 'attendance_date':$scope.view_date, 'lec_or_prac':$scope.lec_or_prac})
			.success(function(data){
				$scope.headings = data;
			});
		}

		//Controller for viewing the attendance register for the specific course either for a day, month, week or semester.
		$scope.selectViewData = function(){
		$http.post("data/view_attendance.php", {'course_code': $scope.course_code, 'week_number':$scope.week_number, 'month_number':$scope.month_number,'attendance_date':$scope.view_date,'lec_or_prac':$scope.lec_or_prac })
			.success(function(data){
				$scope.view_data = data;
				//Call to function for heading the attendance register table. 
				$scope.selecRegisterHeading();
			});
		}
		//Controller for directing pages to the right file.
		$scope.attendanceFormatView = function(){
			if($scope.attendance_view === "Day"){
				window.location.href = 'day_attendance.php';
			}else if($scope.attendance_view === "Week"){
				window.location.href = 'week_attendance.php';
			}else if($scope.attendance_view === "Month"){
				window.location.href = 'month_attendance.php';
			}else if($scope.attendance_view === "Semester"){
				window.location.href = 'semester_attendance.php';
			}
		}
		//Making the fusion chart properties be visible globally for access on the view side
		$scope.myDataSource = {};
		//Controller for the statistical analysis
		$scope.statisticView = function(){
			$http.post("data/view_statistic.php", {'course_code': $scope.course_code,'month_number': $scope.month_number, 'week_number':$scope.week_number, 'attendance_date':$scope.view_date, 'lec_or_prac':$scope.lec_or_prac})
			.success(function(week_data){
				$scope.w_data = week_data;
				$scope.caption = "";
				$scope.subCaption = "";
				if($scope.view_date){
					$scope.caption = "Day Percentage vs Student";
					$scope.subCaption = "Students Day Attendance Analysis";
				}
				else if ($scope.week_) {
					$scope.caption = "Week Percentage vs Student";
					$scope.subCaption = "Students Week Attendance Analysis";
				}else if ($scope.month_) {
					$scope.caption = "Month Percentage vs Student";
					$scope.subCaption = "Students Month Attendance Analysis";
				}else{
					$scope.caption = "Semester Percentage vs Student";
					$scope.subCaption = "Students Semester Attendance Analysis";
				}
				
				$scope.myDataSource = {
	                chart: {
	                    caption: $scope.caption,
	                    subCaption: $scope.subCaption,
	                    yaxisname: "Percentage(%)",
	                    xaxisname: "Students",
				        numbersuffix: "%",
				        yaxismaxvalue: "100",
				        rotatevalues: "0",
				        theme: "zune",
				        palettecolors: "#0075c2"
	                },
	                data:$scope.w_data
	            };
			});
		} 

		//Controller for capturing the students attendance
		$scope.studentAttendance = function(){
			$http.post("data/rfid_attendance.php", {'student_number':$scope.student_number})
			.success(function(data){

				if (data.trim() === "Captured") {
					alert("Captured as attended this lecture.");
				}
				else if (data.trim() === "Not Captured") {
					alert("Something went wrong, not captured.");
				}
				else if (data.trim() === "Already Exist") {
					elert("Already captured as attended this lecture.");
					window.location.href = "index.html";
				}
				else if (data.trim() === "Not registerd") {
					alert("You are not registerd for this lecture");
				}
				else if (data.trim() === "No lecture") {
					alert("This venue has no lecture at this time");
				}
				else if (data.trim() === "Empty") {
					alert("Student number must be entered.");
				}
				else if(data.trim() === "Wait"){
					alert("Wait for a lecturer to activate attendance register.");
				}else{

				}
			});
		}
		
		//Controller for handling the login authentications and validations 
		$scope.lectureLogin = function(){
		$http.post("data/lecture_login.php", {'username': $scope.username,'password': $scope.password})
			.success(function(data) {
				if( data.trim() === $scope.username) {
					window.location.href = 'set_attendance.php';
				} else {
					alert("Please enter correct credentials");
				}
			})
			.error(function() {
				alert("Invalid");
			});
		}
		//Controller for handling the logout function.
		$scope.logout = function(){
			$http.get("data/logout.php")
			.success(function(data){
				if (data.trim() === "Logged out") {
					window.location.href = 'index.html';
				}else{
					alert("Not loged out");
				}
			})
			.error(function(){
				alert("Bad Logout");
			});
		}
		//Calling the above controller functions
		//$scope.selectVenue();
		//$scope.selectCourse();
});