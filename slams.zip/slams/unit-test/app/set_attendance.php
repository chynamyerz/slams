<?php
	session_start();
	//Maintaining the user session. if the user is not logged in then redirect to log in page.
	if(isset($_SESSION['username']) == ''){
?>
	<script>
		alert("You must login first");
		window.location.href = "index.html";
	</script>
<?php
		
	}
?>
<!DOCTYPE html>
<html>
<head>
	
	<meta charset="utf-8">
	<title>smart lecture attendance monitoring system</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="images/logo.ico">
    
	<!-- CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="css/flexslider.css" rel="stylesheet" type="text/css" />
	<link href="css/prettyPhoto.css" rel="stylesheet" type="text/css" />
	<link href="css/animate.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/owl.carousel.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet" type="text/css" />
    
	<!-- FONTS -->
	<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500italic,700,500,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href="http://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">	
	<link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css" />

	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  	<script>
  		$( function() {
    		$( "#datepicker" ).datepicker({
    			changeMonth: true,
    			showWeek: true,
      			firstDay: 1,
      			dateFormat: 'yy-mm-dd'
    		});
  		} );
  	</script>
    
	<!-- SCRIPTS -->
	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
    <!--[if IE]><html class="ie" lang="en"> <![endif]-->
	<script>
		
		//PrettyPhoto
		jQuery(document).ready(function() {
			$("a[rel^='prettyPhoto']").prettyPhoto();
		});
		
		//BlackAndWhite
		$(window).load(function(){
			$('.client_img').BlackAndWhite({
				hoverEffect : true, // default true
				// set the path to BnWWorker.js for a superfast implementation
				webworkerPath : false,
				// for the images with a fluid width and height 
				responsive:true,
				// to invert the hover effect
				invertHoverEffect: false,
				// this option works only on the modern browsers ( on IE lower than 9 it remains always 1)
				intensity:1,
				speed: { //this property could also be just speed: value for both fadeIn and fadeOut
					fadeIn: 300, // 200ms for fadeIn animations
					fadeOut: 300 // 800ms for fadeOut animations
				},
				onImageReady:function(img) {
					// this callback gets executed anytime an image is converted
				}
			});
		});
		
	</script>
	
</head>
<body lang="en" ng-app="ng_App" ng-controller="ng_Controller">

<!-- PRELOADER -->
<img id="preloader" src="images/preloader.gif" alt="" />
<!-- //PRELOADER -->
<div class="preloader_hide">
	
		<!-- HEADER -->
		<header>
			
			<!-- MENU BLOCK -->
			<div class="menu_block">
			
				<!-- CONTAINER -->
				<div class="container clearfix">
					
					<!-- LOGO -->
					<div class="logo pull-left">
						<a href="index.html" ><img src="images/logo.jpg" ></a>
					</div><!-- //LOGO -->
					
					<!-- MENU -->
					<div class="pull-right">
						<nav class="navmenu center">
							<ul>
								<li class="first active scroll_btn"><a href="index.html" >Home</a></li>
								<li class="scroll_btn"><a href="setVenue.php" >Set-Venue</a></li>
								<li class="scroll_btn"><button type="button" class="btn btn-info" data-toggle="modal" data-target="#monitorModal">Monitor-Register</button>
									<!-- Monitor Attendance Modal -->
								  <div class="modal fade" id="monitorModal" role="dialog">
								    <div class="modal-dialog modal-sm">
								    
								      <!-- Modal content-->
								      <div class="modal-content">
								        <div class="modal-header">
								          <button type="button" class="close" data-dismiss="modal">&times;</button>
								          <h4 class="modal-title">Choose format</h4>
								        </div>
								        <div class="modal-body">
								            <form> 
							                    <h3 style="text-align: center;">Select how to view attendance</h3> 
							                    <div class="form-group"> 
							                        <select ng-model="attendance_view" name="attendance_view" id="attendance_view" class="form-control">
														<!--<option>Semester</option>-->
														<option>Month</option>
														<option>Week</option>
														<option>Day</option>
													</select>
							                    </div>
							                    <button ng-click="attendanceFormatView()" class="btn btn-success">Submit</button>
							                </form>
								        </div>
								        <div class="modal-footer">
								          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								        </div>
								      </div>
								      
								    </div>
								  </div>
								</li>
								<li class="scroll_btn last">
									<form>
										<button class="btn btn-primary" ng-click="logout()">
											Logout
										</button>
									</form>
								</li>
							</ul>
						</nav>
					</div><!-- //MENU -->
				</div><!-- //MENU BLOCK -->
			</div><!-- //CONTAINER -->
		</header><!-- //HEADER -->
	<!-- PAGE -->
	<div id="page">	

		<section>
			<div style="float:right; margin-right:1em; margin-top:1em;">
				<h3 style="padding:0px; margin:0px;">
					<?php 
						echo $_SESSION['username'];
					?>
				</h3>
				<p>Loged in</p>
			</div>

			<!-- set number of lectures and practicals -->
			<div id="set_register" style="margin-top:5em; clear:both;">
				<div class="container-fluid">
					<!-- HTML view for adding number of lectures and practical on the specific week and month for the particular course -->
					<h4>Set the number of lectures or practicals for the attendance register in the weekly basis</h4>
					<form>
					<table class="table table-bordered">
					  	<thead>
					    	<tr>
					    		<th>Course Code</th>
					    		<th>Enter Start Date<br>of the Week</th>
					    		<th>Lecture/Practical</th>
					    		<th>Number of<br>Lectures/Practicals</th>
					    		<th>Add Record</th>
					    	</tr>
					  	</thead>
					    
					    <tbody>
					    	<div class="form-group">
								<tr>
									<td>	
										<select ng-model="course_code" ng-click="selectCourse();" class="form-control">
											<option ng-repeat="c in courses">{{c.course_code}}</option>
										</select>
									</td>

									<td>
										<input style="color: black;" type="text" ng-model="week_number" id="datepicker">
									</td>

									<td>
										<select ng-model="lec_or_prac" class="form-control">
											<option>Lectures</option>
											<option>Practicals</option>
										</select>
									</td>
									<td>
										<input type="text" required ng-model="qauntity" placeholder="e.g. 0" class="form-control" style="color:black;">
									</td>
									<td>
										<button ng-click="insertRegisterFormat(course_code, week_number, lec_or_prac, qauntity)" class="btn btn-success btn-block">Set Course</button>
									</td>
								</tr>
							</div>
					    </tbody>
				  	</table>
				  	</form>
				  	<!-- End of the form -->
				</div>
			</div>
			<!-- end of setting for the number of lectures and practicals -->
		</section>
	
	<!-- FOOTER -->
	<footer>	
		<!-- CONTAINER -->
		<div class="container">
			<div class="row copyright">
				<div class="col-lg-12 text-center">
				
				 <p>Created & Managed by S. Myeza @Copyright slams 2016.</p>
				</div>
			</div><!-- //ROW -->
		</div><!-- //CONTAINER -->
	</footer><!-- //FOOTER -->

</div>
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
<script src="js/jquery.nicescroll.min.js" type="text/javascript"></script>
<script src="js/superfish.min.js" type="text/javascript"></script>
<script src="js/jquery.flexslider-min.js" type="text/javascript"></script>
<script src="js/owl.carousel.js" type="text/javascript"></script>
<script src="js/animate.js" type="text/javascript"></script>
<script src="js/jquery.BlackAndWhite.js"></script>
<script src="js/myscript.js" type="text/javascript"></script>

<script src="js/angular.min.js" type="text/javascript"></script>

<script src="js/angular-ui-bootstrap.min.js" type="text/javascript"></script>
<script src="js/angular-ui-bootstrap-tpls.min.js" type="text/javascript"></script>

<script src="js/fusioncharts.js" type="text/javascript"></script>
<script src="js/fusioncharts.charts.js" type="text/javascript"></script>
<script src="js/angular-fusioncharts.min.js" type="text/javascript"></script>

<script src="js/jquery-ui.min.js" type="text/javascript"></script>

<script src="js/angular-animate.js" type="text/javascript"></script>
<script src="js/angular-sanitize.js" type="text/javascript"></script>
<script src="ng_App.js" type="text/javascript"></script>
<script src="scripts/ng_Controller.js" type="text/javascript"></script>

</body>
</html>