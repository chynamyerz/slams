describe('SLAMS Controller', function() {
  beforeEach(module('ng_App'));

  var $controller;
  var $httpBackend;

  beforeEach(inject(function(_$controller_, _$httpBackend_){
    // The injector unwraps the underscores (_) from around the parameter names when matching
    $controller = _$controller_;
    $httpBackend = _$httpBackend_;
  }));

 /*describe('$scope.insertRegisterFormat', function() {
    beforeEach(function(){
      $scope = {};
      $controller = $controller('ng_Controller', { $scope: $scope});
    });

    it('set attendance by entering course_code, week, type(Lectures/Practicals) and number of type', function() {
        
        $scope.insertRegisterFormat("scps312", "2016-10-11", "Lectures", 3);
        $httpBackend
            .expect("POST", "data/register.php", {'course_code':"scps312", 'week_number':"2016-10-11", 'lec_or_prac':"Lectures", 'qauntity':3})
            .respond('L Captured');
        $httpBackend.flush();
        
        expect($scope.respond_insertRegisterFormat).toEqual('L Captured');
    });
  });*/

  describe('$scope.selectCourse', function() {
    beforeEach(function(){
      $scope = {};
      $controller = $controller('ng_Controller', { $scope: $scope});
    });

    it('Retrieve courses from the server', function() {
        
        $scope.selectCourse();
        $httpBackend
            .expect("GET", "data/course.php")
            .respond({"course_code":"scps312","course_description":"Distributed System","course_letter":"E","staff_id":"Mba111"},{"course_code":"scps322","course_description":"Final Year Project","course_letter":"G","staff_id":"Mba111"});
        $httpBackend.flush();
        
        expect($scope.courses).toEqual({"course_code":"scps312","course_description":"Distributed System","course_letter":"E","staff_id":"Mba111"},{"course_code":"scps322","course_description":"Final Year Project","course_letter":"G","staff_id":"Mba111"});
    });
  });

  describe('$scope.selectVenue', function() {
    beforeEach(function(){
      $scope = {};
      $controller = $controller('ng_Controller', { $scope: $scope});
    });

    it('Retrieve venues from the server', function() {
        $scope.selectVenue();
        $httpBackend
            .expect("GET", "data/selectVenue.php")
            .respond({"room_number":"D3D4","building_name":"D-Block"},{"room_number":"E9","building_name":"Physics Lecture Room"},{"room_number":"F11","building_name":"Physics Laboratory for Nuclear Physics"},{"room_number":"F17","building_name":"Physics Physics Laboratory"},{"room_number":"F9","building_name":"Physics Laboratory for Solid State & Material"},{"room_number":"HP Lab 1","building_name":"Computer Laboratory"},{"room_number":"SC101","building_name":"Science Lecture Room 101"},{"room_number":"SC106","building_name":"Science Lecture Room 106"});
        $httpBackend.flush();
        
        expect($scope.venue).toEqual({"room_number":"D3D4","building_name":"D-Block"},{"room_number":"E9","building_name":"Physics Lecture Room"},{"room_number":"F11","building_name":"Physics Laboratory for Nuclear Physics"},{"room_number":"F17","building_name":"Physics Physics Laboratory"},{"room_number":"F9","building_name":"Physics Laboratory for Solid State & Material"},{"room_number":"HP Lab 1","building_name":"Computer Laboratory"},{"room_number":"SC101","building_name":"Science Lecture Room 101"},{"room_number":"SC106","building_name":"Science Lecture Room 106"});
    });
  });
});